# LAPORAN UJIAN TENGAH SEMESTER (UTS)
## WEB SERVICE ENGINEERING (3 SKS)
### "Merancang dan Membangun REST API yang Aman, Terstruktur, dan Dapat Dipertanggungjawabkan"

**Program Studi**: Teknologi Informasi  
**Fakultas**: Tarbiyah dan Keguruan, UIN Antasari Banjarmasin  
**Dosen Pengampu**: Muhayat, M.IT  
**Studi Kasus**: Sistem Layanan Informasi dan Pengaduan Mahasiswa (SIMADU API)  
**Teknologi**: Node.js, Express 5, JSON, JWT, bcrypt  
**Bentuk Pengerjaan**: Individu  

---

## DAFTAR ISI
1. [Bab 1: Analisis Kebutuhan dan Perancangan REST API](#bab-1-analisis-kebutuhan-dan-perancangan-rest-api)
2. [Bab 2: Implementasi Arsitektur REST API Berlapis](#bab-2-implementasi-arsitektur-rest-api-berlapis)
3. [Bab 3: Penerapan Keamanan REST API](#bab-3-penerapan-keamanan-rest-api)
4. [Bab 4: Dokumentasi OpenAPI dan Swagger UI](#bab-4-dokumentasi-openapi-dan-swagger-ui)
5. [Bab 5: Pengujian Fungsional dan Keamanan (12 Skenario)](#bab-5-pengujian-fungsional-dan-keamanan)
6. [Bab 6: Jawaban 10 Pertanyaan Demonstrasi](#bab-6-jawaban-10-pertanyaan-demonstrasi)
7. [Bab 7: Kesimpulan dan Rekomendasi Produksi](#bab-7-kesimpulan-dan-rekomendasi-produksi)

---

## Bab 1: Analisis Kebutuhan dan Perancangan REST API

### 1.1 Identifikasi Aktor dan Wewenang Sistem
Berdasarkan studi kasus Sistem Layanan Informasi dan Pengaduan Mahasiswa (SIMADU), sistem melibatkan dua aktor utama dengan batasan wewenang yang tegas:
1. **Mahasiswa**:
   - Pengguna akhir yang mengajukan laporan atau keluhan terkait fasilitas kampus, layanan akademik, dan teknologi informasi.
   - Memiliki wewenang untuk melihat riwayat pengaduan miliknya sendiri.
   - Memiliki wewenang untuk mengubah judul, kategori, dan deskripsi pengaduan miliknya sendiri *hanya selama status pengaduan masih 'diajukan'*.
   - Memiliki wewenang untuk membatalkan/menghapus pengaduan miliknya sendiri *hanya selama status pengaduan masih 'diajukan'*.
   - **Dilarang keras**: Mengakses atau memodifikasi pengaduan milik mahasiswa lain, mengubah identitas pemilik pengaduan, dan mengubah status penanganan pengaduan.
2. **Administrator Kampus**:
   - Pengelola layanan kampus yang bertanggung jawab memantau tindak lanjut keluhan.
   - Memiliki wewenang melihat rekapitulasi seluruh pengaduan dari seluruh mahasiswa kampus.
   - Memiliki wewenang melihat detail spesifik pengaduan siapa pun.
   - Memiliki wewenang memperbarui status penanganan pengaduan (`diajukan` &rarr; `diproses` &rarr; `selesai`).
   - **Dilarang**: Membuat pengaduan mengatasnamakan mahasiswa, mengubah identitas pemilik pengaduan, atau mengedit substansi laporan mahasiswa.

### 1.2 Resource Utama Sistem
- Resource Utama: `pengaduan` (`/api/pengaduan`)
- Sub-resource Pendukung: `auth` (`/api/auth/login`)

### 1.3 Tabel Kontrak Endpoint API

| Metode HTTP | Endpoint URI | Fungsi dan Hak Akses | Status Berhasil | Status Gagal |
| :--- | :--- | :--- | :---: | :---: |
| **POST** | `/api/auth/login` | Autentikasi kredensial pengguna (NIM/Admin & Password). Mengembalikan token JWT. Terbuka untuk umum. | `200 OK` | `400`, `401` |
| **GET** | `/api/pengaduan` | Mengambil daftar pengaduan. Mahasiswa: hanya miliknya; Admin: seluruh data kampus. | `200 OK` | `401` |
| **GET** | `/api/pengaduan/:id` | Mengambil detail satu pengaduan. Mahasiswa hanya miliknya (milik orang lain menghasilkan 403). Admin: bebas. | `200 OK` | `400`, `401`, `403`, `404` |
| **POST** | `/api/pengaduan` | Menambahkan pengaduan baru. Khusus role Mahasiswa. `mahasiswaId` diambil otomatis dari token JWT. | `201 Created` | `400`, `401`, `403` |
| **PUT** | `/api/pengaduan/:id` | Memperbarui judul, kategori, dan deskripsi. Khusus mahasiswa pemilik dan status masih `diajukan`. | `200 OK` | `400`, `401`, `403`, `404` |
| **PATCH** | `/api/pengaduan/:id/status` | Memperbarui status penanganan laporan (diajukan/diproses/selesai). Khusus role Administrator. | `200 OK` | `400`, `401`, `403`, `404` |
| **DELETE** | `/api/pengaduan/:id` | Menghapus pengaduan. Khusus mahasiswa pemilik dan hanya selama status masih `diajukan`. | `200 OK` | `400`, `401`, `403`, `404` |

### 1.4 Struktur JSON Request dan Response Standar
Format standar yang diterapkan:
- **Format Respons Sukses**:
  ```json
  {
    "success": true,
    "message": "Deskripsi aksi berhasil",
    "data": { ... }
  }
  ```
- **Format Respons Error**:
  ```json
  {
    "success": false,
    "message": "Pesan deskripsi kesalahan yang informatif tanpa membocorkan info internal"
  }
  ```

### 1.5 Diagram Komunikasi Consumer-Provider
```
+---------------------+         +----------------------+
|   Aplikasi Web      |         |   Aplikasi Mobile    |
| (Frontend Consumer) |         | (Flutter / React Nat)|
+----------+----------+         +----------+-----------+
           |                               |
           | HTTP/HTTPS JSON Request       | HTTP/HTTPS JSON Request
           | Header: Authorization: Bearer | Header: Authorization: Bearer
           +---------------+---------------+
                           |
                           v
        +-------------------------------------+
        |       SIMADU REST API PROVIDER      |
        |        (Node.js / Express 5)        |
        +-------------------------------------+
        |  Port 3000 | OpenAPI 3.0 Documented |
        +-------------------------------------+
```

### 1.6 Diagram Arsitektur Berlapis (Layered Architecture)
```
Incoming Request ---> [ Router Layer (routes/index.cjs, pengaduanRoutes.cjs) ]
                             |
                             v
                      [ Middleware Layer ]
                      ├── authMiddleware.cjs        (Verifikasi JWT Bearer Token)
                      ├── roleMiddleware.cjs        (Pengecekan Wewenang RBAC)
                      └── validationMiddleware.cjs  (Validasi Payload & Strict Whitelist)
                             |
                             v
                      [ Controller Layer (pengaduanController.cjs) ]
                      (HTTP Req/Res Parsing, Parameter Extraction, HTTP Status)
                             |
                             v
                      [ Service Layer (pengaduanService.cjs) ]
                      (Business Logic, State Invariant Rules, Data Ownership Check)
                             |
                             v
                      [ Repository Layer (pengaduanRepository.cjs) ]
                      (Data Access Layer, CRUD Operations, Thread-Safe In-Memory Store)
                             |
                             v
                      [ Centralized Error Handler (errorHandler.cjs) ]
                      (Tangkap exception, filter 500 error, kirim standar JSON)
```

---

## Bab 2: Implementasi Arsitektur REST API Berlapis

### 2.1 Struktur Proyek SIMADU API
Sesuai rekomendasi pada dokumen soal ujian, struktur direktori proyek tersusun sebagai berikut:
```
simadu-api/
├── src/
│   ├── controllers/
│   │   ├── authController.cjs
│   │   └── pengaduanController.cjs
│   ├── services/
│   │   ├── authService.cjs
│   │   └── pengaduanService.cjs
│   ├── repositories/
│   │   ├── userRepository.cjs
│   │   └── pengaduanRepository.cjs
│   ├── routes/
│   │   ├── index.cjs
│   │   ├── authRoutes.cjs
│   │   └── pengaduanRoutes.cjs
│   └── middleware/
│       ├── authMiddleware.cjs
│       ├── roleMiddleware.cjs
│       ├── validationMiddleware.cjs
│       └── errorHandler.cjs
├── docs/
│   └── openapi.json
├── tests/
│   ├── run12Scenarios.cjs
│   ├── generateScreenshots.cjs
│   └── results.json
├── screenshots/
├── app.cjs
├── server.cjs
├── package.json
├── .env.example
├── .gitignore
└── README.md
```

### 2.2 Pembagian Tanggung Jawab Komponen
- **Router (`src/routes/`)**: Memetakan path URL dan HTTP verb ke controller yang bersangkutan, serta merangkai middleware filter.
- **Middleware (`src/middleware/`)**: Melindungi endpoint melalui pemeriksaan token autentikasi (`authMiddleware`), verifikasi otorisasi role (`roleMiddleware`), validasi format payload dan pelarangan field sensitif (`validationMiddleware`), dan sentralisasi penanganan galat (`errorHandler`).
- **Controller (`src/controllers/`)**: Mengelola protokol HTTP, mengekstrak data dari `req.body`, `req.params`, dan `req.user`, memanggil service, serta mengirim status code HTTP dan body JSON.
- **Service (`src/services/`)**: Mengorkestrasi aturan bisnis, memvalidasi kategori dan enum status, menegakkan kepemilikan data (data ownership), dan memeriksa invarian status (hanya status `diajukan` yang boleh diubah/dihapus).
- **Repository (`src/repositories/`)**: Menangani manipulasi data (CRUD) secara mandiri tanpa terikat logika HTTP.

---

## Bab 3: Penerapan Keamanan REST API

### 3.1 Autentikasi dan Enkripsi Password (bcrypt)
Password pengguna tidak pernah disimpan dalam format teks biasa (plaintext). Seluruh password disimpan dalam bentuk hash kriptografis menggunakan algoritma `bcrypt` dengan *salt rounds* 10 pada `src/repositories/userRepository.cjs`. Saat pengguna login, `src/services/authService.cjs` memverifikasi kesesuaian menggunakan `bcrypt.compare(password, user.passwordHash)`.

Data uji awal yang disediakan:
- **Mahasiswa 1**: ID `240101`, Nama `Budi Santoso`, Role `mahasiswa`, Password `Password123!` (bcrypt hashed)
- **Mahasiswa 2**: ID `240102`, Nama `Siti Rahma`, Role `mahasiswa`, Password `Password123!` (bcrypt hashed)
- **Administrator**: ID `admin01`, Nama `Pak Joko (Admin)`, Role `admin`, Password `AdminPassword123!` (bcrypt hashed)

### 3.2 Bearer Token JWT dengan Mekanisme Kedaluwarsa
Setelah login berhasil, sistem menerbitkan JSON Web Token (JWT) yang di-sign menggunakan secret key server. Token menyertakan claims identitas:
```json
{
  "sub": "240101",
  "nama": "Budi Santoso",
  "role": "mahasiswa",
  "prodi": "Teknologi Informasi",
  "iat": 1795409198,
  "exp": 1795412798
}
```
Token memiliki masa berlaku 1 jam (`JWT_EXPIRES_IN=1h`). Middleware `authMiddleware.cjs` memeriksa header `Authorization: Bearer <token>`, memverifikasi signature, dan menolak token yang telah kedaluwarsa atau dimanipulasi dengan respons `401 Unauthorized`.

### 3.3 Matriks Hak Akses (Role-Based Access Control)

| Operasi | Endpoint | Mahasiswa | Admin | Aturan Kebijakan |
| :--- | :--- | :---: | :---: | :--- |
| **Melihat Pengaduan Sendiri** | `GET /api/pengaduan/:id` | :heavy_check_mark: | :heavy_check_mark: | Mahasiswa hanya ID miliknya; Admin siapa saja. |
| **Melihat Semua Pengaduan** | `GET /api/pengaduan` | :x: (Hanya miliknya) | :heavy_check_mark: (Semua) | Mahasiswa difilter otomatis berdasarkan `user.sub`. |
| **Membuat Pengaduan** | `POST /api/pengaduan` | :heavy_check_mark: | :x: | MahasiswaId dari token JWT; Admin dilarang melapor. |
| **Mengubah Pengaduan Sendiri**| `PUT /api/pengaduan/:id` | :heavy_check_mark: (Hanya 'diajukan') | :x: | Ditolak 403 jika status sudah diproses/selesai. |
| **Menghapus Pengaduan Sendiri**| `DELETE /api/pengaduan/:id`| :heavy_check_mark: (Hanya 'diajukan') | :x: | Ditolak 403 jika status bukan 'diajukan'. |
| **Mengubah Status Pengaduan** | `PATCH /api/pengaduan/:id/status`| :x: (403 Forbidden) | :heavy_check_mark: | Hanya wewenang admin (diajukan/diproses/selesai). |

### 3.4 Validasi Input Ketat dan Pencegahan Mass Assignment
- **Pelarangan Field Terlarang**: Client dilarang menyetel `id`, `mahasiswaId`, `status`, `createdAt`, atau `updatedAt` pada request body POST dan PUT. Jika dikirimkan, sistem memutus request dengan `400 Bad Request`.
- **Validasi Kategori**: Kategori pengaduan dibatasi pada enum `['Fasilitas', 'Akademik', 'TI']`.
- **Validasi Parameter ID**: Parameter `:id` wajib bilangan bulat positif.
- **Centralized Error Handling**: Error level 500 disamarkan tanpa kebocoran stack trace demi keamanan sistem.

---

## Bab 4: Dokumentasi OpenAPI dan Swagger UI

SIMADU API mendokumentasikan seluruh kontrak antarmukanya secara presisi menggunakan spesifikasi **OpenAPI 3.0.3** yang disimpan pada berkas `docs/openapi.json`. Halaman Swagger UI interaktif dapat diakses langsung oleh pengembang dan penguji melalui peramban web pada alamat:
```
http://localhost:3000/api-docs
```

Dokumentasi memuat rincian parameter, skema request body, skema respons sukses dan error, serta konfigurasi otentikasi Bearer JWT.

---

## Bab 5: Pengujian Fungsional dan Keamanan

### 5.1 Rekapitulasi Hasil 12 Skenario Pengujian Wajib

| No | Skenario Pengujian | Metode & URL | Hasil Harapan | Hasil Aktual | Status |
| :-: | :--- | :--- | :---: | :---: | :---: |
| **1** | Login dengan kredensial benar | `POST /api/auth/login` | `200 OK`, token diterima | `200 OK`, token diterima | **PASSED** |
| **2** | Login dengan password salah | `POST /api/auth/login` | `401 Unauthorized` | `401 Unauthorized` | **PASSED** |
| **3** | Akses endpoint terlindungi tanpa token | `GET /api/pengaduan` | `401 Unauthorized` | `401 Unauthorized` | **PASSED** |
| **4** | Akses menggunakan token tidak valid | `GET /api/pengaduan` | `401 Unauthorized` | `401 Unauthorized` | **PASSED** |
| **5** | Mahasiswa membuat pengaduan valid | `POST /api/pengaduan` | `201 Created` | `201 Created` | **PASSED** |
| **6** | Mahasiswa membaca pengaduan sendiri | `GET /api/pengaduan/4` | `200 OK` | `200 OK` | **PASSED** |
| **7** | Mahasiswa membaca pengaduan orang lain | `GET /api/pengaduan/3` | `403 Forbidden` | `403 Forbidden` | **PASSED** |
| **8** | Mahasiswa mengubah status pengaduan | `PATCH /api/pengaduan/1/status` | `403 Forbidden` | `403 Forbidden` | **PASSED** |
| **9** | Admin melihat seluruh pengaduan | `GET /api/pengaduan` | `200 OK` | `200 OK` | **PASSED** |
| **10**| Admin memperbarui status pengaduan | `PATCH /api/pengaduan/1/status` | `200 OK` | `200 OK` | **PASSED** |
| **11**| Membuat pengaduan dengan field wajib kosong | `POST /api/pengaduan` | `400 Bad Request` | `400 Bad Request` | **PASSED** |
| **12**| Mengakses ID pengaduan yang tidak ditemukan | `GET /api/pengaduan/99999` | `404 Not Found` | `404 Not Found` | **PASSED** |

**Tingkat Keberhasilan**: 12 dari 12 Skenario Pengujian Lulus 100%.

Bukti tangkapan layar (screenshot) aktual tersimpan lengkap di dalam folder `simadu-api/screenshots/` dan telah disematkan secara utuh pada berkas PDF resmi `Laporan_UTS_WSE_SIMADU_API.pdf`.

---

## Bab 6: Jawaban 10 Pertanyaan Demonstrasi

Berikut adalah pertanggungjawaban teknis atas 10 pertanyaan evaluasi pemahaman individual:

### 1. Apa perbedaan autentikasi dan otorisasi? Tunjukkan implementasinya di dalam kode.
- **Autentikasi (Authentication - "Who are you?")**: Proses memverifikasi kebenaran identitas pengguna.
  - *Implementasi*:
    - Di `src/services/authService.cjs`: Memvalidasi ID dan password plaintext terhadap hash bcrypt menggunakan `await bcrypt.compare(password, user.passwordHash)`. Jika valid, server menerbitkan token JWT dengan klaim `{ sub: user.id, nama: user.nama, role: user.role }`.
    - Di `src/middleware/authMiddleware.cjs`: Memeriksa keberadaan header `Authorization: Bearer <token>` dan memverifikasi tanda tangan digital token menggunakan `jwt.verify(token, secretKey)`. Jika sah, data didekode dan dilampirkan ke `req.user`.
- **Otorisasi (Authorization - "What are you allowed to do?")**: Proses penentuan apakah pengguna yang telah terotentikasi memiliki wewenang untuk melakukan aksi tertentu pada sumber daya yang diminta.
  - *Implementasi*:
    - Di `src/middleware/roleMiddleware.cjs`: Menegakkan Role-Based Access Control (RBAC), misalnya `requireRole('admin')` memastikan hanya peran administrator yang boleh mengakses `PATCH /api/pengaduan/:id/status`, sedangkan peran mahasiswa ditolak dengan kode status `403 Forbidden`.
    - Di `src/services/pengaduanService.cjs`: Menegakkan otorisasi kepemilikan data (*Data Ownership Authorization*), memeriksa `if (pengaduan.mahasiswaId !== user.sub) throw 403`, memastikan mahasiswa tidak dapat membaca, mengubah, atau menghapus pengaduan mahasiswa lain.

### 2. Mengapa mahasiswa yang berhasil login belum tentu boleh mengakses semua endpoint?
- Karena autentikasi dan otorisasi merupakan dua lapisan kontrol keamanan yang independen (*Separation of Concerns*). Keberhasilan login hanya membuktikan bahwa akun terdaftar secara sah di sistem (*valid identity*), bukan berarti memegang hak istimewa (*privilege*) atas seluruh sumber daya.
- Sistem menerapkan prinsip **Least Privilege** (hak akses minimum):
  - Mahasiswa hanya berperan sebagai pelapor keluhan (*reporter*), sehingga wewenangnya dibatasi pada pengelolaan pengaduan miliknya sendiri. Jika mahasiswa diizinkan mengakses seluruh endpoint, mahasiswa dapat membaca rahasia laporan rekan lain atau bahkan memanipulasi status laporannya sendiri menjadi 'selesai' tanpa tindak lanjut kampus.
  - Endpoint pembaruan status (`PATCH /api/pengaduan/:id/status`) merupakan wewenang operasional Administrator kampus. Otorisasi RBAC memastikan peran mahasiswa dicegah mengakses fungsionalitas tersebut.

### 3. Apa perbedaan respons HTTP 401 dan 403?
- **HTTP 401 Unauthorized (Secara teknis: Unauthenticated)**:
  - Mengindikasikan bahwa server tidak mengetahui siapa klien tersebut karena kredensial autentikasi tidak disediakan, format token salah (`Bearer <token>`), signature JWT rusak, token telah kedaluwarsa, atau kombinasi username/password salah saat login.
  - Klien dapat mengulang permintaan yang sama jika menyertakan token/kredensial yang valid.
- **HTTP 403 Forbidden (Authenticated, but Not Authorized)**:
  - Mengindikasikan bahwa server *sudah mengenali identitas klien secara sah* (`req.user` ada dan valid), namun server *secara tegas menolak memberikan izin* untuk melakukan operasi yang diminta.
  - Mengirimkan ulang token yang sama tidak akan mengubah hasil karena klien memang tidak memiliki wewenang atau hak akses atas data/endpoint tersebut.

### 4. Bagaimana API memastikan seorang mahasiswa hanya dapat mengubah pengaduannya sendiri?
- API memastikan hal ini melalui 3 lapis perlindungan:
  1. **Identitas Berasal dari Token Server (Bukan Client Input)**: Parameter pemilik (`mahasiswaId`) tidak pernah diambil dari URL atau request body. Identitas pengguna diekstrak langsung dari klaim `req.user.sub` pada JWT yang telah di-sign server. Bahkan `validationMiddleware` akan menolak permintaan dengan status `400` jika client mencoba mengirimkan body berisi `mahasiswaId`.
  2. **Validasi Kepemilikan pada Service Layer (`src/services/pengaduanService.cjs`)**:
     Sebelum operasi pembaruan dijalankan, service mengambil data pengaduan dari repository berdasarkan ID, lalu membandingkan ID pemilik:
     ```javascript
     if (pengaduan.mahasiswaId !== user.sub) {
       const err = new Error('Akses ditolak: Anda bukan pemilik dari pengaduan ini');
       err.statusCode = 403;
       throw err;
     }
     ```
  3. **Invarian Status Pengaduan**:
     Service memeriksa apakah status pengaduan masih `diajukan`. Jika pengaduan sudah berstatus `diproses` atau `selesai`, pembaruan tetap ditolak dengan status 403 demi menjaga integritas data penanganan kampus.

### 5. Mengapa password harus di-hash dan mengapa token tidak boleh dicatat ke log?
- **Alasan Password Harus Di-hash**:
  - Mencegah bahaya kebocoran data (*data breach*). Jika basis data terekspos akibat *SQL Injection* atau pencurian file, password tidak dapat dibaca oleh pihak penyerang.
  - Penggunaan fungsi hash adaptif dengan *salt* unik (seperti `bcrypt` pada `userRepository.cjs`) memastikan nilai hash bersifat satu arah (*irreversible*), memperlambat serangan *brute force*, dan kebal terhadap serangan pencocokan kamus (*rainbow tables*). Ini melindungi pengguna yang menggunakan password sama di berbagai platform (*credential stuffing prevention*).
- **Alasan Token Tidak Boleh Dicatat ke Log (No Token Logging)**:
  - Bearer Token adalah *bearer credential* (kredensial pembawa). Siapa pun yang memegang token tersebut dapat melakukan aksi atas nama pengguna (*identity theft / session hijacking*) tanpa perlu mengetahui password pengguna.
  - File log server (seperti `access.log` atau stream APM) sering kali diakses oleh banyak pihak (tim DevOps, analis sistem, penyedia layanan analitik eksternal) dan sering disimpan dalam bentuk teks biasa tanpa enkripsi ketat. Jika token dicatat dalam log, kebocoran berkas log sama berbahayanya dengan kebocoran sesi login aktif pengguna.

### 6. Bagaimana sebuah input yang salah ditangani oleh middleware dan error handler?
- Alur penanganan kesalahan input (*middleware pipeline*):
  1. **Parsing JSON Request**: `express.json()` memeriksa sintaks JSON. Jika JSON malformed/rusak, parsing error ditangkap oleh `errorHandler.cjs` dan mengembalikan respons `400 Bad Request`.
  2. **Validasi Field Terlarang & Field Tak Dikenal**: Di `validationMiddleware.cjs`, sistem memeriksa apakah client menyisipkan atribut ilegal seperti `id`, `mahasiswaId`, atau `status`. Jika ada, request langsung diputus (*early exit*) dengan respons 400.
  3. **Validasi Field Wajib & Nilai Enum**: Memeriksa apakah `judul`, `kategori`, atau `deskripsi` kosong atau hanya berupa spasi, serta memastikan kategori termasuk dalam `['Fasilitas', 'Akademik', 'TI']`. Jika tidak sesuai, dikembalikan respons 400.
  4. **Centralized Error Handler**: Setiap error yang dilempar dari controller/service diteruskan ke `errorHandler.cjs` melalui `next(err)`. Middleware ini memformat respons JSON secara konsisten: `{ "success": false, "message": err.message }` dengan kode status yang tepat (400, 401, 403, 404), serta menyamarkan error 500 tanpa membocorkan tumpukan memori/kode internal.

### 7. Apa perbedaan HTTPS dengan autentikasi Bearer Token?
- **HTTPS (Lapisan Transport / TLS)**:
  - Mengamankan pipa transmisi data antara klien dan server.
  - Menjamin tiga hal: **Kerahasiaan** (enkripsi data end-to-end), **Integritas** (mencegah modifikasi data oleh penyerang man-in-the-middle), dan **Otentisitas Server** (memastikan klien terhubung ke server kampus yang sah melalui sertifikat digital SSL/TLS).
- **Bearer Token (Lapisan Aplikasi / HTTP Authorization)**:
  - Mengidentifikasi subjek pengguna dan menegakkan otorisasi hak akses di dalam logika aplikasi web service secara *stateless*.
- **Hubungan Keduanya**:
  - Bearer Token *tidak menggantikan* HTTPS dan *sangat bergantung* padanya. Jika Bearer Token dikirim melalui protokol HTTP biasa tanpa enkripsi TLS, penyerang yang berada pada jaringan lokal (misal Wi-Fi kampus) dapat menyadap (*packet sniffing*) token tersebut dalam bentuk plain text dan membajak akun pengguna. Sebaliknya, HTTPS melindungi kerahasiaan token tersebut saat transit di jaringan.

### 8. Bagaimana membuktikan bahwa input yang ditolak tidak mengubah data?
- Pembuktian dilakukan melalui metodologi **State Invariance Verification** (verifikasi status sebelum dan sesudah permintaan ditolak):
  1. **Snapshot Awal (Pre-condition)**: Lakukan pemanggilan `GET /api/pengaduan/1` untuk mencatat nilai status, judul, dan waktu pembaruan (misal: ID 1 berstatus `diajukan` dan judul "AC Ruang Lab Komputer 2 Tidak Dingin").
  2. **Injeksi Request Tidak Sah (Trigger Rejection)**: Kirimkan request yang melanggar aturan, contohnya:
     - Mahasiswa mengirimkan `PATCH /api/pengaduan/1/status` berisi `{"status": "selesai"}` (Ditolak dengan `403 Forbidden`).
     - Atau mahasiswa mengirimkan `PUT /api/pengaduan/1` dengan body kosong atau field judul string kosong `{"judul": ""}` (Ditolak dengan `400 Bad Request`).
  3. **Pemeriksaan Pasca-Penolakan (Post-condition)**: Panggil kembali `GET /api/pengaduan/1`. Hasil pembacaan membuktikan bahwa data tetap utuh 100% tanpa ada perubahan atribut apa pun.
- Hal ini terjadi karena arsitektur middleware dan service menerapkan pola *Fail-Fast*: validasi dieksekusi terlebih dahulu sebelum alur program menyentuh fungsi mutasi pada repository, sehingga operasi bersifat atomik.

### 9. Mengapa dokumentasi Swagger yang tampil belum cukup membuktikan API berjalan dengan benar?
- Dokumentasi Swagger UI hanyalah representasi visual dari berkas kontrak statis (`openapi.json`). Keberadaan Swagger UI hanya membuktikan bahwa pengembang telah mendefinisikan *skema deklaratif* tentang bagaimana antarmuka API seharusnya bekerja, bukan bukti bahwa sistem berjalan secara fungsional.
- Swagger UI yang tampil sempurna bisa saja memiliki kelemahan berikut jika tidak diuji:
  - Kode di balik controller belum terhubung ke database atau hanya mengembalikan data tiruan (*mock/dummy response*).
  - Aturan otorisasi kepemilikan data tidak diterapkan, sehingga pengguna masih bisa mengakses data pengguna lain.
  - Validasi input bocor, memungkinkan client menyuntikkan field ilegal yang merusak integritas sistem.
- Oleh karena itu, pembuktian keabsahan sistem **wajib dilakukan melalui eksekusi pengujian dinamis** (seperti 12 skenario pengujian pada Bab 5), yang memverifikasi bahwa respons aktual (baik status 200/201 maupun penolakan 400/401/403/404) benar-benar ditegakkan oleh server secara konsisten.

### 10. Apa yang harus diperbaiki agar layanan ini layak diterapkan pada lingkungan produksi (Production Readiness)?
Untuk menaikkan tingkat kematangan SIMADU API ke standar produksi industri (*enterprise production grade*), berikut rekomendasi perbaikan teknis yang harus diterapkan:
1. **Penyimpanan Data Permanen (Persistent Database)**: Mengganti penyimpanan array in-memory dengan Database Relasional Enterprise (seperti PostgreSQL atau MySQL) yang mendukung transaksi ACID, indeks performa, dan migrasi skema menggunakan ORM/Query Builder seperti Prisma atau Knex.js.
2. **Proteksi Rate Limiting & Brute-Force**: Memasang middleware `express-rate-limit` dan Redis untuk membatasi frekuensi request, khususnya pada endpoint `/api/auth/login` (misalnya maksimal 5 percobaan login gagal per 15 menit) guna mencegah serangan *credential stuffing* dan *Denial of Service (DoS)*.
3. **Mekanisme Refresh Token dan Pencabutan Sesi (Token Revocation)**: Menerapkan pola dual-token (Access Token berumur pendek ~15 menit dan Refresh Token berumur 7 hari yang disimpan dalam cookie HttpOnly bersertifikat Secure). Menyediakan blacklist token di Redis untuk memungkinkan logout seketika atau pembatalan sesi saat kata sandi diganti.
4. **Keamanan Header HTTP & TLS Wajib**: Memasang library `helmet` untuk menyuntikkan header keamanan standar (seperti Content-Security-Policy, X-Frame-Options, HSTS), serta mewajibkan koneksi TLS 1.3 (HTTPS).
5. **Sistem Logging Terstruktur & Monitoring (APM)**: Mengintegrasikan logger terstruktur seperti `Pino` atau `Winston` yang memiliki filter sensor otomatis terhadap data sensitif (PII masking), serta menghubungkannya ke sistem observabilitas seperti Prometheus, Grafana, atau Sentry untuk pelaporan galat waktu nyata.
6. **Pipeline Otomatisasi CI/CD & Automated Testing**: Mengintegrasikan skrip pengujian (Jest/Supertest) ke dalam pipeline GitHub Actions agar setiap pembaruan kode diuji secara otomatis sebelum di-deploy ke klaster kontainer Docker/Kubernetes.

---

## Bab 7: Kesimpulan dan Rekomendasi Produksi

Pengembangan Sistem Layanan Informasi dan Pengaduan Mahasiswa (SIMADU REST API) telah berhasil diselesaikan dengan memenuhi seluruh kriteria teknis yang dipersyaratkan pada Ujian Tengah Semester mata kuliah Web Service Engineering:
1. Arsitektur REST API berlapis telah diimplementasikan secara bersih dan terstruktur dengan pemisahan tanggung jawab yang tegas antara Router, Middleware, Controller, Service, dan Repository.
2. Mekanisme keamanan enterprise telah diterapkan meliputi enkripsi password dengan hash bcrypt, manajemen sesi stateless berbasis Bearer Token JWT dengan kedaluwarsa 1 jam, kontrol otorisasi peran (RBAC) dan kepemilikan data (Data Ownership Authorization), serta penolakan ketat terhadap field ilegal.
3. Dokumentasi API lengkap menggunakan standar OpenAPI 3.0 dan antarmuka Swagger UI interaktif telah tersedia pada endpoint `/api-docs`.
4. Seluruh 12 skenario pengujian fungsional dan keamanan berhasil dieksekusi dengan tingkat kelulusan 100%, disertai dengan bukti screenshot respons aktual dan pertanggungjawaban teknis atas 10 pertanyaan demonstrasi.
