const app = require('./app.cjs');

const PORT = process.env.PORT || 3000;

const server = app.listen(PORT, () => {
  console.log('================================================================');
  console.log(`🚀 SIMADU REST API Server is running on port: ${PORT}`);
  console.log(`📖 Swagger UI Documentation: http://localhost:${PORT}/api-docs`);
  console.log(`🔍 Health Check: http://localhost:${PORT}/api/health`);
  console.log(`🔐 Auth Endpoint: http://localhost:${PORT}/api/auth/login`);
  console.log(`📋 Pengaduan Endpoint: http://localhost:${PORT}/api/pengaduan`);
  console.log('================================================================');
});

module.exports = server;
