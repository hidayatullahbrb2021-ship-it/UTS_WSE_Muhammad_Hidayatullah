const jwt = require('jsonwebtoken');

/**
 * AuthMiddleware
 * Memeriksa keberadaan dan keabsahan Bearer Token pada HTTP Authorization Header.
 * Jika valid, payload token dilampirkan ke objek req.user.
 */
function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];

  if (!authHeader) {
    return res.status(401).json({
      success: false,
      message: 'Akses ditolak: Authorization header tidak ditemukan. Silakan sertakan Bearer Token.'
    });
  }

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return res.status(401).json({
      success: false,
      message: 'Format token salah. Format yang diharapkan adalah: Bearer <token>'
    });
  }

  const token = parts[1];
  const secretKey = process.env.JWT_SECRET || 'fallback_secret_key_uts_wse_20261';

  try {
    const decoded = jwt.verify(token, secretKey);
    req.user = decoded;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Akses ditolak: Token autentikasi telah kedaluwarsa. Silakan login kembali.'
      });
    }

    return res.status(401).json({
      success: false,
      message: 'Akses ditolak: Token autentikasi tidak valid atau rusak.'
    });
  }
}

module.exports = authMiddleware;
