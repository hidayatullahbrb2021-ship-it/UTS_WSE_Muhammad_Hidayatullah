/**
 * ErrorHandler Middleware
 * Menangani seluruh error secara terpusat dengan response JSON standar.
 * Memastikan status HTTP 400, 401, 403, 404, dan 500 diberikan secara presisi
 * tanpa membocorkan stack trace teknis di level 500 ke client.
 */
function errorHandler(err, req, res, next) {
  // Tangani error parsing JSON bawaan Express
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({
      success: false,
      message: 'Format JSON pada request body tidak valid (Malformed JSON)'
    });
  }

  const statusCode = err.statusCode || (res.statusCode !== 200 ? res.statusCode : 500);

  // Jika 500 (Internal Server Error), sembunyikan detail teknis demi keamanan
  if (statusCode === 500) {
    console.error('[InternalServerError]', err);
    return res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan internal pada server. Silakan hubungi administrator.'
    });
  }

  // Error klien yang terdefinisi (400, 401, 403, 404)
  return res.status(statusCode).json({
    success: false,
    message: err.message || 'Terjadi kesalahan pada permintaan'
  });
}

module.exports = errorHandler;
