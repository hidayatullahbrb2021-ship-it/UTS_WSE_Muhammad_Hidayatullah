/**
 * RoleMiddleware (RBAC)
 * Membatasi akses endpoint berdasarkan role pengguna.
 * @param  {...string} allowedRoles - Daftar role yang diizinkan (misal: 'admin', 'mahasiswa')
 */
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !req.user.role) {
      return res.status(401).json({
        success: false,
        message: 'Akses ditolak: Informasi otentikasi pengguna tidak ditemukan.'
      });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Akses ditolak: Pengguna dengan peran '${req.user.role}' tidak memiliki hak akses untuk operasi ini. Hak akses yang dibutuhkan: ${allowedRoles.join(', ')}.`
      });
    }

    next();
  };
}

module.exports = { requireRole };
