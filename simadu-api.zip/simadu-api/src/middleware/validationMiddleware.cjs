/**
 * ValidationMiddleware
 * Memastikan payload request memenuhi spesifikasi kontrak data dan mencegah
 * manipulasi field sensitif (seperti id, status, atau mahasiswaId).
 */

function validateLogin(req, res, next) {
  const { id, password } = req.body || {};

  if (!id || typeof id !== 'string' || id.trim() === '') {
    return res.status(400).json({
      success: false,
      message: 'Validasi gagal: ID pengguna (NIM/Username) wajib diisi'
    });
  }

  if (!password || typeof password !== 'string' || password.trim() === '') {
    return res.status(400).json({
      success: false,
      message: 'Validasi gagal: Password wajib diisi'
    });
  }

  next();
}

function validateCreatePengaduan(req, res, next) {
  const body = req.body || {};
  const allowedKeys = ['judul', 'kategori', 'deskripsi'];
  const forbiddenKeys = ['id', 'mahasiswaId', 'status', 'createdAt', 'updatedAt'];

  // Cek apakah ada field terlarang yang coba disisipkan oleh client
  for (const key of forbiddenKeys) {
    if (key in body) {
      return res.status(400).json({
        success: false,
        message: `Validasi gagal: Field '${key}' tidak boleh ditentukan oleh client secara mandiri.`
      });
    }
  }

  // Cek field asing yang tidak dikenal
  const extraKeys = Object.keys(body).filter(k => !allowedKeys.includes(k));
  if (extraKeys.length > 0) {
    return res.status(400).json({
      success: false,
      message: `Validasi gagal: Field tidak dikenal tidak diperbolehkan: ${extraKeys.join(', ')}`
    });
  }

  const { judul, kategori, deskripsi } = body;

  if (!judul || typeof judul !== 'string' || judul.trim() === '') {
    return res.status(400).json({
      success: false,
      message: 'Validasi gagal: Field judul wajib diisi dan tidak boleh kosong'
    });
  }

  if (!kategori || typeof kategori !== 'string' || kategori.trim() === '') {
    return res.status(400).json({
      success: false,
      message: 'Validasi gagal: Field kategori wajib diisi dan tidak boleh kosong'
    });
  }

  const validCategories = ['Fasilitas', 'Akademik', 'TI'];
  if (!validCategories.includes(kategori.trim())) {
    return res.status(400).json({
      success: false,
      message: `Validasi gagal: Nilai kategori '${kategori}' tidak valid. Pilihan valid: ${validCategories.join(', ')}`
    });
  }

  if (!deskripsi || typeof deskripsi !== 'string' || deskripsi.trim() === '') {
    return res.status(400).json({
      success: false,
      message: 'Validasi gagal: Field deskripsi wajib diisi dan tidak boleh kosong'
    });
  }

  next();
}

function validateUpdatePengaduan(req, res, next) {
  const body = req.body || {};
  const allowedKeys = ['judul', 'kategori', 'deskripsi'];
  const forbiddenKeys = ['id', 'mahasiswaId', 'status', 'createdAt', 'updatedAt'];

  for (const key of forbiddenKeys) {
    if (key in body) {
      return res.status(400).json({
        success: false,
        message: `Validasi gagal: Field '${key}' tidak boleh diubah oleh endpoint ini.`
      });
    }
  }

  const extraKeys = Object.keys(body).filter(k => !allowedKeys.includes(k));
  if (extraKeys.length > 0) {
    return res.status(400).json({
      success: false,
      message: `Validasi gagal: Field tidak dikenal: ${extraKeys.join(', ')}`
    });
  }

  const { judul, kategori, deskripsi } = body;

  if (!judul && !kategori && !deskripsi) {
    return res.status(400).json({
      success: false,
      message: 'Validasi gagal: Minimal satu field (judul, kategori, atau deskripsi) harus disediakan'
    });
  }

  if (judul !== undefined && (typeof judul !== 'string' || judul.trim() === '')) {
    return res.status(400).json({
      success: false,
      message: 'Validasi gagal: Judul tidak boleh berupa string kosong'
    });
  }

  if (deskripsi !== undefined && (typeof deskripsi !== 'string' || deskripsi.trim() === '')) {
    return res.status(400).json({
      success: false,
      message: 'Validasi gagal: Deskripsi tidak boleh berupa string kosong'
    });
  }

  if (kategori !== undefined) {
    const validCategories = ['Fasilitas', 'Akademik', 'TI'];
    if (!validCategories.includes(kategori.trim())) {
      return res.status(400).json({
        success: false,
        message: `Validasi gagal: Nilai kategori '${kategori}' tidak valid. Pilihan valid: ${validCategories.join(', ')}`
      });
    }
  }

  next();
}

function validateUpdateStatus(req, res, next) {
  const body = req.body || {};
  const keys = Object.keys(body);

  if (!('status' in body)) {
    return res.status(400).json({
      success: false,
      message: "Validasi gagal: Field 'status' wajib disertakan dalam request body"
    });
  }

  if (keys.length > 1) {
    return res.status(400).json({
      success: false,
      message: 'Validasi gagal: Endpoint pembaruan status hanya menerima field status'
    });
  }

  const validStatuses = ['diajukan', 'diproses', 'selesai'];
  if (!validStatuses.includes(body.status)) {
    return res.status(400).json({
      success: false,
      message: `Validasi gagal: Nilai status '${body.status}' tidak valid. Pilihan valid: ${validStatuses.join(', ')}`
    });
  }

  next();
}

function validateIdParam(req, res, next) {
  const idStr = req.params.id;
  const idNum = Number(idStr);

  if (!Number.isInteger(idNum) || idNum <= 0) {
    return res.status(400).json({
      success: false,
      message: `Validasi gagal: ID parameter '${idStr}' harus berupa bilangan bulat positif.`
    });
  }

  next();
}

module.exports = {
  validateLogin,
  validateCreatePengaduan,
  validateUpdatePengaduan,
  validateUpdateStatus,
  validateIdParam
};
