const express = require('express');
const router = express.Router();

const authRoutes = require('./authRoutes.cjs');
const pengaduanRoutes = require('./pengaduanRoutes.cjs');

// Routing API
router.use('/auth', authRoutes);
router.use('/pengaduan', pengaduanRoutes);

// Root health check endpoint
router.get('/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    service: 'SIMADU REST API',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

module.exports = router;
