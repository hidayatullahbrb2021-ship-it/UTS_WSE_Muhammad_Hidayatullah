const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController.cjs');
const { validateLogin } = require('../middleware/validationMiddleware.cjs');

/**
 * Route: POST /api/auth/login
 * Deskripsi: Autentikasi kredensial pengguna dan penerbitan JWT Bearer Token
 */
router.post('/login', validateLogin, (req, res, next) => authController.login(req, res, next));

module.exports = router;
