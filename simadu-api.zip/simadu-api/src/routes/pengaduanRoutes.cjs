const express = require('express');
const router = express.Router();

const pengaduanController = require('../controllers/pengaduanController.cjs');
const authMiddleware = require('../middleware/authMiddleware.cjs');
const { requireRole } = require('../middleware/roleMiddleware.cjs');
const {
  validateCreatePengaduan,
  validateUpdatePengaduan,
  validateUpdateStatus,
  validateIdParam
} = require('../middleware/validationMiddleware.cjs');

// Seluruh endpoint /api/pengaduan memerlukan otentikasi Bearer Token
router.use(authMiddleware);

/**
 * Route: GET /api/pengaduan
 * Deskripsi: Mengambil daftar pengaduan (Mahasiswa melihat miliknya, Admin melihat semua)
 */
router.get('/', (req, res, next) => pengaduanController.getAll(req, res, next));

/**
 * Route: GET /api/pengaduan/:id
 * Deskripsi: Mengambil detail spesifik pengaduan
 */
router.get('/:id', validateIdParam, (req, res, next) => pengaduanController.getById(req, res, next));

/**
 * Route: POST /api/pengaduan
 * Deskripsi: Menambahkan pengaduan baru (Hanya Mahasiswa)
 */
router.post(
  '/',
  requireRole('mahasiswa'),
  validateCreatePengaduan,
  (req, res, next) => pengaduanController.create(req, res, next)
);

/**
 * Route: PUT /api/pengaduan/:id
 * Deskripsi: Mengubah judul, kategori, dan deskripsi pengaduan (Hanya Mahasiswa pemilik & status diajukan)
 */
router.put(
  '/:id',
  validateIdParam,
  requireRole('mahasiswa'),
  validateUpdatePengaduan,
  (req, res, next) => pengaduanController.update(req, res, next)
);

/**
 * Route: PATCH /api/pengaduan/:id/status
 * Deskripsi: Memperbarui status penanganan pengaduan (Hanya Admin)
 */
router.patch(
  '/:id/status',
  validateIdParam,
  requireRole('admin'),
  validateUpdateStatus,
  (req, res, next) => pengaduanController.updateStatus(req, res, next)
);

/**
 * Route: DELETE /api/pengaduan/:id
 * Deskripsi: Menghapus pengaduan (Hanya Mahasiswa pemilik & status diajukan)
 */
router.delete(
  '/:id',
  validateIdParam,
  requireRole('mahasiswa'),
  (req, res, next) => pengaduanController.delete(req, res, next)
);

module.exports = router;
