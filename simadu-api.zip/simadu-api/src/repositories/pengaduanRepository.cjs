/**
 * PengaduanRepository
 * Mengelola penyimpanan dan manipulasi data entitas Pengaduan.
 * Menyediakan initial seed data untuk pengujian multi-aktor dan kepemilikan data.
 */
class PengaduanRepository {
  constructor() {
    this.initialData = [
      {
        id: 1,
        mahasiswaId: '240101',
        judul: 'AC Ruang Lab Komputer 2 Tidak Dingin',
        kategori: 'Fasilitas',
        deskripsi: 'Suhu ruangan lab komputer 2 sangat panas saat praktikum berlangsung, pendingin ruangan tidak berfungsi maksimal.',
        status: 'diajukan',
        createdAt: '2026-11-20T08:30:00.000Z',
        updatedAt: '2026-11-20T08:30:00.000Z'
      },
      {
        id: 2,
        mahasiswaId: '240101',
        judul: 'KRS Semester Ganjil Belum Diverifikasi DPA',
        kategori: 'Akademik',
        deskripsi: 'Pengajuan Kartu Rencana Studi masih berstatus pending dan belum mendapat persetujuan dosen pembimbing akademik.',
        status: 'diproses',
        createdAt: '2026-11-21T09:15:00.000Z',
        updatedAt: '2026-11-21T10:00:00.000Z'
      },
      {
        id: 3,
        mahasiswaId: '240102',
        judul: 'Akses Wifi Kampus Terputus di Gedung F Lantai 3',
        kategori: 'TI',
        deskripsi: 'Sinyal koneksi wireless eduroam sering mengalami RTO dan putus-nyambung di area perkuliahan lantai 3.',
        status: 'diajukan',
        createdAt: '2026-11-22T13:45:00.000Z',
        updatedAt: '2026-11-22T13:45:00.000Z'
      }
    ];

    this.pengaduanList = JSON.parse(JSON.stringify(this.initialData));
    this.currentId = 3;
  }

  /**
   * Reset data ke kondisi awal (berguna saat pengujian berulang)
   */
  reset() {
    this.pengaduanList = JSON.parse(JSON.stringify(this.initialData));
    this.currentId = 3;
  }

  /**
   * Mengambil semua pengaduan (akses Administrator)
   * @returns {Array<object>}
   */
  findAll() {
    return this.pengaduanList.map(item => ({ ...item }));
  }

  /**
   * Mengambil pengaduan milik mahasiswa tertentu
   * @param {string} mahasiswaId
   * @returns {Array<object>}
   */
  findByMahasiswaId(mahasiswaId) {
    return this.pengaduanList
      .filter(item => item.mahasiswaId === mahasiswaId)
      .map(item => ({ ...item }));
  }

  /**
   * Mengambil pengaduan berdasarkan ID unik
   * @param {number} id
   * @returns {object|null}
   */
  findById(id) {
    const item = this.pengaduanList.find(p => p.id === Number(id));
    return item ? { ...item } : null;
  }

  /**
   * Menambahkan pengaduan baru
   * ID otomatis di-generate secara incremental.
   * Status awal selalu 'diajukan'.
   * @param {object} payload
   * @returns {object}
   */
  create({ mahasiswaId, judul, kategori, deskripsi }) {
    this.currentId += 1;
    const now = new Date().toISOString();
    const newPengaduan = {
      id: this.currentId,
      mahasiswaId,
      judul,
      kategori,
      deskripsi,
      status: 'diajukan',
      createdAt: now,
      updatedAt: now
    };
    this.pengaduanList.push(newPengaduan);
    return { ...newPengaduan };
  }

  /**
   * Memperbarui judul, kategori, dan deskripsi pengaduan
   * @param {number} id
   * @param {object} updateData
   * @returns {object|null}
   */
  update(id, { judul, kategori, deskripsi }) {
    const index = this.pengaduanList.findIndex(p => p.id === Number(id));
    if (index === -1) return null;

    const current = this.pengaduanList[index];
    const updated = {
      ...current,
      judul: judul !== undefined ? judul : current.judul,
      kategori: kategori !== undefined ? kategori : current.kategori,
      deskripsi: deskripsi !== undefined ? deskripsi : current.deskripsi,
      updatedAt: new Date().toISOString()
    };
    this.pengaduanList[index] = updated;
    return { ...updated };
  }

  /**
   * Memperbarui status penanganan pengaduan (oleh Admin)
   * @param {number} id
   * @param {string} status ('diajukan' | 'diproses' | 'selesai')
   * @returns {object|null}
   */
  updateStatus(id, status) {
    const index = this.pengaduanList.findIndex(p => p.id === Number(id));
    if (index === -1) return null;

    this.pengaduanList[index] = {
      ...this.pengaduanList[index],
      status,
      updatedAt: new Date().toISOString()
    };
    return { ...this.pengaduanList[index] };
  }

  /**
   * Menghapus pengaduan berdasarkan ID
   * @param {number} id
   * @returns {boolean}
   */
  delete(id) {
    const index = this.pengaduanList.findIndex(p => p.id === Number(id));
    if (index === -1) return false;
    this.pengaduanList.splice(index, 1);
    return true;
  }
}

module.exports = new PengaduanRepository();
