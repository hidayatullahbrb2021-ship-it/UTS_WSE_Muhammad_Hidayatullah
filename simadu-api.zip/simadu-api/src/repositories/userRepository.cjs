const bcrypt = require('bcryptjs');

/**
 * UserRepository
 * Mengelola data pengguna (Mahasiswa dan Administrator).
 * Password disimpan dalam bentuk hash bcrypt demi memenuhi standar keamanan OWASP.
 */
class UserRepository {
  constructor() {
    this.users = [
      {
        id: '240101',
        nama: 'Budi Santoso',
        role: 'mahasiswa',
        prodi: 'Teknologi Informasi',
        // Password plaintext: Password123!
        passwordHash: bcrypt.hashSync('Password123!', 10)
      },
      {
        id: '240102',
        nama: 'Siti Rahma',
        role: 'mahasiswa',
        prodi: 'Teknologi Informasi',
        // Password plaintext: Password123!
        passwordHash: bcrypt.hashSync('Password123!', 10)
      },
      {
        id: 'admin01',
        nama: 'Pak Joko (Administrator SIMADU)',
        role: 'admin',
        prodi: 'Biro Administrasi Akademik & Kemahasiswaan',
        // Password plaintext: AdminPassword123!
        passwordHash: bcrypt.hashSync('AdminPassword123!', 10)
      }
    ];
  }

  /**
   * Mencari pengguna berdasarkan ID (NIM atau username admin)
   * @param {string} id
   * @returns {object|null}
   */
  findById(id) {
    const user = this.users.find(u => u.id === id);
    return user ? { ...user } : null;
  }

  /**
   * Mengambil semua pengguna (tanpa data password hash)
   * @returns {Array<object>}
   */
  findAll() {
    return this.users.map(({ passwordHash, ...userWithoutPassword }) => ({ ...userWithoutPassword }));
  }
}

module.exports = new UserRepository();
