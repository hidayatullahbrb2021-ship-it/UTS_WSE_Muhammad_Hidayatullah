const pengaduanRepository = require('../repositories/pengaduanRepository.cjs');

/**
 * PengaduanService
 * Mengorkestrasi aturan bisnis, kepemilikan data, dan hak akses entitas Pengaduan.
 */
class PengaduanService {
  /**
   * Mengambil daftar pengaduan sesuai peran pengguna
   * Mahasiswa: hanya melihat pengaduannya sendiri
   * Admin: melihat seluruh pengaduan yang ada
   * @param {object} user - Payload pengguna hasil otentikasi JWT
   * @returns {Array<object>}
   */
  async getAllPengaduan(user) {
    if (user.role === 'admin') {
      return pengaduanRepository.findAll();
    }
    // Peran mahasiswa hanya melihat miliknya sendiri
    return pengaduanRepository.findByMahasiswaId(user.sub);
  }

  /**
   * Mengambil detail pengaduan berdasarkan ID
   * Menerapkan pembatasan: mahasiswa tidak boleh melihat pengaduan milik mahasiswa lain (403)
   * @param {number} id
   * @param {object} user
   * @returns {object}
   */
  async getPengaduanById(id, user) {
    const pengaduan = pengaduanRepository.findById(id);
    if (!pengaduan) {
      const err = new Error(`Pengaduan dengan ID ${id} tidak ditemukan`);
      err.statusCode = 404;
      throw err;
    }

    // Pengecekan otorisasi kepemilikan data
    if (user.role === 'mahasiswa' && pengaduan.mahasiswaId !== user.sub) {
      const err = new Error('Akses ditolak: Anda tidak memiliki izin untuk melihat pengaduan milik mahasiswa lain');
      err.statusCode = 403;
      throw err;
    }

    return pengaduan;
  }

  /**
   * Menambahkan pengaduan baru
   * Hanya diizinkan untuk peran 'mahasiswa'. Identitas mahasiswa diambil dari token otentikasi.
   * @param {object} data - { judul, kategori, deskripsi }
   * @param {object} user - User payload
   * @returns {object}
   */
  async createPengaduan({ judul, kategori, deskripsi }, user) {
    if (user.role !== 'mahasiswa') {
      const err = new Error('Akses ditolak: Hanya mahasiswa yang berhak mengajukan pengaduan');
      err.statusCode = 403;
      throw err;
    }

    const validCategories = ['Fasilitas', 'Akademik', 'TI'];
    if (!validCategories.includes(kategori)) {
      const err = new Error(`Kategori tidak valid. Kategori yang diperbolehkan: ${validCategories.join(', ')}`);
      err.statusCode = 400;
      throw err;
    }

    return pengaduanRepository.create({
      mahasiswaId: user.sub,
      judul: judul.trim(),
      kategori,
      deskripsi: deskripsi.trim()
    });
  }

  /**
   * Mengubah judul, kategori, dan deskripsi pengaduan
   * Aturan: Hanya boleh diubah oleh mahasiswa pemiliknya dan hanya selama status masih 'diajukan'
   * @param {number} id
   * @param {object} updateData
   * @param {object} user
   * @returns {object}
   */
  async updatePengaduan(id, { judul, kategori, deskripsi }, user) {
    if (user.role !== 'mahasiswa') {
      const err = new Error('Akses ditolak: Hanya mahasiswa pemilik yang berhak mengubah isi pengaduan');
      err.statusCode = 403;
      throw err;
    }

    const pengaduan = pengaduanRepository.findById(id);
    if (!pengaduan) {
      const err = new Error(`Pengaduan dengan ID ${id} tidak ditemukan`);
      err.statusCode = 404;
      throw err;
    }

    if (pengaduan.mahasiswaId !== user.sub) {
      const err = new Error('Akses ditolak: Anda bukan pemilik dari pengaduan ini');
      err.statusCode = 403;
      throw err;
    }

    if (pengaduan.status !== 'diajukan') {
      const err = new Error(
        `Pengaduan tidak dapat diubah karena sedang berstatus '${pengaduan.status}'. Perubahan hanya diperbolehkan saat status 'diajukan'.`
      );
      err.statusCode = 403;
      throw err;
    }

    if (kategori) {
      const validCategories = ['Fasilitas', 'Akademik', 'TI'];
      if (!validCategories.includes(kategori)) {
        const err = new Error(`Kategori tidak valid. Kategori yang diperbolehkan: ${validCategories.join(', ')}`);
        err.statusCode = 400;
        throw err;
      }
    }

    return pengaduanRepository.update(id, {
      judul: judul !== undefined ? judul.trim() : undefined,
      kategori: kategori !== undefined ? kategori : undefined,
      deskripsi: deskripsi !== undefined ? deskripsi.trim() : undefined
    });
  }

  /**
   * Memperbarui status penanganan pengaduan
   * Aturan: Hanya boleh dilakukan oleh Administrator
   * @param {number} id
   * @param {string} status
   * @param {object} user
   * @returns {object}
   */
  async updatePengaduanStatus(id, status, user) {
    if (user.role !== 'admin') {
      const err = new Error('Akses ditolak: Hanya administrator yang memiliki izin memperbarui status penanganan pengaduan');
      err.statusCode = 403;
      throw err;
    }

    const validStatuses = ['diajukan', 'diproses', 'selesai'];
    if (!validStatuses.includes(status)) {
      const err = new Error(`Status tidak valid. Nilai yang diperbolehkan: ${validStatuses.join(', ')}`);
      err.statusCode = 400;
      throw err;
    }

    const pengaduan = pengaduanRepository.findById(id);
    if (!pengaduan) {
      const err = new Error(`Pengaduan dengan ID ${id} tidak ditemukan`);
      err.statusCode = 404;
      throw err;
    }

    return pengaduanRepository.updateStatus(id, status);
  }

  /**
   * Menghapus pengaduan
   * Aturan: Hanya boleh dilakukan oleh mahasiswa pemilik dan hanya selama status masih 'diajukan'
   * @param {number} id
   * @param {object} user
   * @returns {boolean}
   */
  async deletePengaduan(id, user) {
    if (user.role !== 'mahasiswa') {
      const err = new Error('Akses ditolak: Hanya mahasiswa pemilik yang berhak menghapus pengaduan');
      err.statusCode = 403;
      throw err;
    }

    const pengaduan = pengaduanRepository.findById(id);
    if (!pengaduan) {
      const err = new Error(`Pengaduan dengan ID ${id} tidak ditemukan`);
      err.statusCode = 404;
      throw err;
    }

    if (pengaduan.mahasiswaId !== user.sub) {
      const err = new Error('Akses ditolak: Anda bukan pemilik dari pengaduan ini');
      err.statusCode = 403;
      throw err;
    }

    if (pengaduan.status !== 'diajukan') {
      const err = new Error(
        `Pengaduan tidak dapat dihapus karena sedang berstatus '${pengaduan.status}'. Penghapusan hanya diperbolehkan saat status 'diajukan'.`
      );
      err.statusCode = 403;
      throw err;
    }

    return pengaduanRepository.delete(id);
  }
}

module.exports = new PengaduanService();
