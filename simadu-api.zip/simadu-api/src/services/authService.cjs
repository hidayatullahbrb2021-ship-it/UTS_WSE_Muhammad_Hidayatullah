const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const userRepository = require('../repositories/userRepository.cjs');

/**
 * AuthService
 * Menangani logika bisnis autentikasi pengguna dan penerbitan JSON Web Token (JWT).
 */
class AuthService {
  /**
   * Autentikasi pengguna berdasarkan ID dan password
   * @param {string} id - NIM mahasiswa atau ID administrator
   * @param {string} password - Password plaintext
   * @returns {object} Token JWT dan profil pengguna
   */
  async login(id, password) {
    if (!id || !password) {
      const err = new Error('ID pengguna dan password wajib diisi');
      err.statusCode = 400;
      throw err;
    }

    const user = userRepository.findById(String(id).trim());
    if (!user) {
      // Keamanan: Pesan error generik untuk mencegah user enumeration
      const err = new Error('Kredensial login tidak valid (ID atau password salah)');
      err.statusCode = 401;
      throw err;
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      const err = new Error('Kredensial login tidak valid (ID atau password salah)');
      err.statusCode = 401;
      throw err;
    }

    // Terbitkan JWT Bearer Token dengan claims identitas dan role
    const payload = {
      sub: user.id,
      nama: user.nama,
      role: user.role,
      prodi: user.prodi
    };

    const secretKey = process.env.JWT_SECRET || 'fallback_secret_key_uts_wse_20261';
    const expiresIn = process.env.JWT_EXPIRES_IN || '1h';

    const token = jwt.sign(payload, secretKey, { expiresIn });

    return {
      token,
      tokenType: 'Bearer',
      expiresIn,
      user: {
        id: user.id,
        nama: user.nama,
        role: user.role,
        prodi: user.prodi
      }
    };
  }
}

module.exports = new AuthService();
