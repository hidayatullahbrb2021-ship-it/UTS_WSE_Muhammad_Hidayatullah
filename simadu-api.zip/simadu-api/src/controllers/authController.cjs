const authService = require('../services/authService.cjs');

/**
 * AuthController
 * Menangani request HTTP yang berhubungan dengan autentikasi pengguna.
 */
class AuthController {
  async login(req, res, next) {
    try {
      const { id, password } = req.body;
      const result = await authService.login(id, password);

      return res.status(200).json({
        success: true,
        message: 'Login berhasil. Token otentikasi telah diterbitkan.',
        data: result
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new AuthController();
