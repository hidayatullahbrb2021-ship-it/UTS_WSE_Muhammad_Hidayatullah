const pengaduanService = require('../services/pengaduanService.cjs');

/**
 * PengaduanController
 * Mengontrol alur request-response HTTP untuk resource Pengaduan.
 */
class PengaduanController {
  async getAll(req, res, next) {
    try {
      const data = await pengaduanService.getAllPengaduan(req.user);
      return res.status(200).json({
        success: true,
        message: 'Daftar pengaduan berhasil diambil',
        count: data.length,
        data
      });
    } catch (error) {
      next(error);
    }
  }

  async getById(req, res, next) {
    try {
      const id = Number(req.params.id);
      const data = await pengaduanService.getPengaduanById(id, req.user);
      return res.status(200).json({
        success: true,
        data
      });
    } catch (error) {
      next(error);
    }
  }

  async create(req, res, next) {
    try {
      const data = await pengaduanService.createPengaduan(req.body, req.user);
      return res.status(201).json({
        success: true,
        message: 'Pengaduan berhasil dibuat dan diajukan',
        data
      });
    } catch (error) {
      next(error);
    }
  }

  async update(req, res, next) {
    try {
      const id = Number(req.params.id);
      const data = await pengaduanService.updatePengaduan(id, req.body, req.user);
      return res.status(200).json({
        success: true,
        message: 'Pengaduan berhasil diperbarui',
        data
      });
    } catch (error) {
      next(error);
    }
  }

  async updateStatus(req, res, next) {
    try {
      const id = Number(req.params.id);
      const data = await pengaduanService.updatePengaduanStatus(id, req.body.status, req.user);
      return res.status(200).json({
        success: true,
        message: 'Status penanganan pengaduan berhasil diperbarui',
        data
      });
    } catch (error) {
      next(error);
    }
  }

  async delete(req, res, next) {
    try {
      const id = Number(req.params.id);
      await pengaduanService.deletePengaduan(id, req.user);
      return res.status(200).json({
        success: true,
        message: 'Pengaduan berhasil dihapus'
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new PengaduanController();
