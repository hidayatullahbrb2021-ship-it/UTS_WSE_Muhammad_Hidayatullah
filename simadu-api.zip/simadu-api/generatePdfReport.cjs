const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const ROOT_DIR = path.resolve(__dirname, '..');
const SCREENSHOTS_DIR = path.join(__dirname, 'screenshots');
const OUT_PDF_ROOT = path.join(ROOT_DIR, 'Laporan_UTS_WSE_SIMADU_API.pdf');
const OUT_PDF_SIMADU = path.join(__dirname, 'Laporan_UTS_WSE_SIMADU_API.pdf');
const TEMP_HTML = path.join(__dirname, 'temp_report.html');

function getBase64Image(filename) {
  const filepath = path.join(SCREENSHOTS_DIR, filename);
  if (!fs.existsSync(filepath)) return '';
  const data = fs.readFileSync(filepath);
  return `data:image/png;base64,${data.toString('base64')}`;
}

const swaggerBase64 = getBase64Image('swagger_ui.png');
const terminalBase64 = getBase64Image('terminal_test_execution.png');
const scenariosBase64 = {};
for (let i = 1; i <= 12; i++) {
  const pad = String(i).padStart(2, '0');
  scenariosBase64[i] = getBase64Image(`skenario_${pad}.png`);
}

const scenarioDetails = [
  { no: 1, title: 'Login dengan Kredensial Benar', method: 'POST', endpoint: '/api/auth/login', expected: '200 OK', actual: '200 OK', status: 'LULUS', desc: 'Pengguna (Mahasiswa NIM 240101) mengirimkan ID dan password yang benar. Server memverifikasi hash bcrypt dan menerbitkan JWT Bearer Token dengan claims identitas dan masa aktif 1 jam.' },
  { no: 2, title: 'Login dengan Password Salah', method: 'POST', endpoint: '/api/auth/login', expected: '401 Unauthorized', actual: '401 Unauthorized', status: 'LULUS', desc: 'Pengguna mengirimkan password yang salah. Server menolak otentikasi dengan pesan generik tanpa membocorkan apakah ID atau password yang salah.' },
  { no: 3, title: 'Akses Endpoint Terlindungi Tanpa Token', method: 'GET', endpoint: '/api/pengaduan', expected: '401 Unauthorized', actual: '401 Unauthorized', status: 'LULUS', desc: 'Client mencoba mengakses resource pengaduan tanpa menyertakan HTTP Authorization Header. Middleware authMiddleware langsung memblokir request.' },
  { no: 4, title: 'Akses Menggunakan Token Tidak Valid', method: 'GET', endpoint: '/api/pengaduan', expected: '401 Unauthorized', actual: '401 Unauthorized', status: 'LULUS', desc: 'Client menyertakan Authorization header berisi token palsu/rusak. Verifikasi jwt.verify gagal dan mengembalikan respons 401.' },
  { no: 5, title: 'Mahasiswa Membuat Pengaduan Valid', method: 'POST', endpoint: '/api/pengaduan', expected: '201 Created', actual: '201 Created', status: 'LULUS', desc: 'Mahasiswa mengirim data pengaduan lengkap (judul, kategori, deskripsi). Nilai mahasiswaId diambil otomatis dari token JWT, status diatur menjadi diajukan, dan data berhasil disimpan.' },
  { no: 6, title: 'Mahasiswa Membaca Pengaduan Sendiri', method: 'GET', endpoint: '/api/pengaduan/4', expected: '200 OK', actual: '200 OK', status: 'LULUS', desc: 'Mahasiswa mengakses detail pengaduan miliknya sendiri. Service memverifikasi kesesuaian mahasiswaId dengan sub pada token JWT.' },
  { no: 7, title: 'Mahasiswa Mencoba Membaca Pengaduan Orang Lain', method: 'GET', endpoint: '/api/pengaduan/3', expected: '403 Forbidden', actual: '403 Forbidden', status: 'LULUS', desc: 'Mahasiswa 1 (240101) mencoba mengakses pengaduan ID 3 milik Mahasiswa 2 (240102). Otorisasi kepemilikan data menolak akses dengan status 403.' },
  { no: 8, title: 'Mahasiswa Mencoba Mengubah Status Pengaduan', method: 'PATCH', endpoint: '/api/pengaduan/1/status', expected: '403 Forbidden', actual: '403 Forbidden', status: 'LULUS', desc: 'Mahasiswa mencoba mengubah status pengaduan menjadi diproses. RoleMiddleware mendeteksi role mahasiswa dan menolak operasi karena hanya admin yang berhak.' },
  { no: 9, title: 'Admin Melihat Seluruh Pengaduan', method: 'GET', endpoint: '/api/pengaduan', expected: '200 OK', actual: '200 OK', status: 'LULUS', desc: 'Administrator kampus memanggil endpoint daftar pengaduan. Sistem mengembalikan seluruh data pengaduan dari seluruh mahasiswa tanpa batasan.' },
  { no: 10, title: 'Admin Memperbarui Status Pengaduan', method: 'PATCH', endpoint: '/api/pengaduan/1/status', expected: '200 OK', actual: '200 OK', status: 'LULUS', desc: 'Administrator memperbarui status pengaduan ID 1 dari diajukan menjadi diproses. Pembaruan divalidasi dan tersimpan di repository.' },
  { no: 11, title: 'Membuat Pengaduan dengan Field Wajib Kosong', method: 'POST', endpoint: '/api/pengaduan', expected: '400 Bad Request', actual: '400 Bad Request', status: 'LULUS', desc: 'Client mengirim request POST pengaduan dengan judul kosong. ValidationMiddleware mendeteksi kegagalan field wajib dan menghentikan request.' },
  { no: 12, title: 'Mengakses ID Pengaduan yang Tidak Ditemukan', method: 'GET', endpoint: '/api/pengaduan/99999', expected: '404 Not Found', actual: '404 Not Found', status: 'LULUS', desc: 'Client mengakses ID pengaduan yang tidak ada di database. Service melempar error 404 dengan pesan informatif.' }
];

const htmlContent = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Laporan UTS Web Service Engineering - SIMADU API</title>
  <style>
    @page {
      size: A4;
      margin: 20mm 15mm 20mm 15mm;
    }
    * { box-sizing: border-box; }
    body {
      font-family: 'Segoe UI', Arial, Helvetica, sans-serif;
      font-size: 11pt;
      line-height: 1.6;
      color: #1a202c;
      background: #ffffff;
      margin: 0;
      padding: 0;
    }
    .cover-page {
      page-break-after: always;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      min-height: 88vh;
      border: 3px double #2b6cb0;
      padding: 40px;
    }
    .cover-institution {
      font-size: 16pt;
      font-weight: 700;
      letter-spacing: 0.05em;
      color: #2b6cb0;
      margin-bottom: 6px;
      text-transform: uppercase;
    }
    .cover-faculty {
      font-size: 13pt;
      font-weight: 600;
      color: #4a5568;
      margin-bottom: 25px;
    }
    .cover-divider {
      width: 120px;
      height: 4px;
      background: #3182ce;
      margin: 0 auto 30px auto;
      border-radius: 2px;
    }
    .cover-title {
      font-size: 22pt;
      font-weight: 800;
      color: #1a365d;
      line-height: 1.3;
      margin-bottom: 15px;
      text-transform: uppercase;
    }
    .cover-subtitle {
      font-size: 13pt;
      font-style: italic;
      color: #4a5568;
      max-width: 650px;
      margin-bottom: 40px;
    }
    .cover-project-box {
      background: #edf2f7;
      border-left: 5px solid #3182ce;
      padding: 16px 24px;
      text-align: left;
      width: 100%;
      max-width: 550px;
      border-radius: 6px;
      margin-bottom: 45px;
    }
    .cover-project-box table {
      width: 100%;
      border-collapse: collapse;
    }
    .cover-project-box td {
      padding: 5px 8px;
      font-size: 11pt;
    }
    .cover-project-box td.label {
      font-weight: 700;
      width: 140px;
      color: #2d3748;
    }
    .cover-footer {
      margin-top: auto;
      font-size: 11pt;
      color: #718096;
      font-weight: 600;
    }
    h1 {
      font-size: 17pt;
      color: #1a365d;
      border-bottom: 2px solid #3182ce;
      padding-bottom: 6px;
      margin-top: 25px;
      margin-bottom: 15px;
      text-transform: uppercase;
      page-break-after: avoid;
    }
    h2 {
      font-size: 13pt;
      color: #2b6cb0;
      margin-top: 20px;
      margin-bottom: 10px;
      border-bottom: 1px dashed #cbd5e0;
      padding-bottom: 4px;
      page-break-after: avoid;
    }
    h3 {
      font-size: 11.5pt;
      color: #2d3748;
      margin-top: 14px;
      margin-bottom: 6px;
      page-break-after: avoid;
    }
    p {
      margin-bottom: 10px;
      text-align: justify;
    }
    ul, ol {
      margin-top: 5px;
      margin-bottom: 12px;
      padding-left: 25px;
    }
    li {
      margin-bottom: 4px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 14px 0 20px 0;
      font-size: 9.5pt;
      page-break-inside: avoid;
    }
    th, td {
      border: 1px solid #cbd5e0;
      padding: 8px 10px;
      text-align: left;
    }
    th {
      background-color: #ebf8ff;
      color: #2c5282;
      font-weight: 700;
      text-transform: uppercase;
      font-size: 9pt;
      letter-spacing: 0.03em;
    }
    tr:nth-child(even) {
      background-color: #f7fafc;
    }
    .badge {
      display: inline-block;
      padding: 2px 7px;
      font-size: 8.5pt;
      font-weight: 700;
      border-radius: 4px;
    }
    .badge-get { background: #ebf8ff; color: #2b6cb0; border: 1px solid #bee3f8; }
    .badge-post { background: #f0fff4; color: #276749; border: 1px solid #c6f6d5; }
    .badge-put { background: #fffaf0; color: #c05621; border: 1px solid #feebc8; }
    .badge-patch { background: #faf5ff; color: #6b46c1; border: 1px solid #e9d8fd; }
    .badge-delete { background: #fff5f5; color: #9b2c2c; border: 1px solid #fed7d7; }
    .badge-pass { background: #f0fff4; color: #22543d; font-weight: 800; }
    .code-box {
      background: #f7fafc;
      border: 1px solid #e2e8f0;
      border-left: 4px solid #3182ce;
      padding: 10px 14px;
      font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
      font-size: 9pt;
      margin: 10px 0;
      overflow-x: auto;
      page-break-inside: avoid;
      line-height: 1.45;
    }
    .screenshot-container {
      margin: 18px 0;
      text-align: center;
      page-break-inside: avoid;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px;
      background: #fafafa;
    }
    .screenshot-container img {
      max-width: 100%;
      height: auto;
      border-radius: 6px;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
    }
    .screenshot-caption {
      font-size: 9pt;
      font-style: italic;
      color: #718096;
      margin-top: 6px;
    }
    .qa-box {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 14px 18px;
      margin-bottom: 18px;
      page-break-inside: avoid;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .qa-question {
      font-weight: 700;
      color: #2b6cb0;
      font-size: 11pt;
      margin-bottom: 8px;
      border-bottom: 1px solid #edf2f7;
      padding-bottom: 5px;
    }
    .qa-answer {
      font-size: 10.5pt;
      color: #2d3748;
      text-align: justify;
      line-height: 1.6;
    }
    .page-break {
      page-break-after: always;
    }
    .diagram-box {
      background: #f8fafc;
      border: 1px solid #cbd5e0;
      border-radius: 6px;
      padding: 15px;
      font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
      font-size: 9pt;
      white-space: pre;
      line-height: 1.4;
      margin: 12px 0;
      page-break-inside: avoid;
    }
  </style>
</head>
<body>

  <!-- COVER PAGE -->
  <div class="cover-page">
    <div class="cover-institution">Universitas Islam Negeri Antasari Banjarmasin</div>
    <div class="cover-faculty">Program Studi Teknologi Informasi &bull; Fakultas Tarbiyah dan Keguruan</div>
    <div class="cover-divider"></div>
    <div class="cover-title">Laporan Ujian Tengah Semester (UTS)<br>Web Service Engineering</div>
    <div class="cover-subtitle">"Merancang dan Membangun REST API yang Aman, Terstruktur, dan Dapat Dipertanggungjawabkan"</div>

    <div class="cover-project-box">
      <table>
        <tr><td class="label">Mata Kuliah</td><td>: Web Service Engineering (3 SKS)</td></tr>
        <tr><td class="label">Dosen Pengampu</td><td>: Muhayat, M.IT</td></tr>
        <tr><td class="label">Topik Studi Kasus</td><td>: Sistem Layanan Informasi dan Pengaduan Mahasiswa (SIMADU API)</td></tr>
        <tr><td class="label">Teknologi</td><td>: Node.js, Express 5, JSON, JWT, bcrypt</td></tr>
        <tr><td class="label">Bentuk Pengerjaan</td><td>: Individu</td></tr>
        <tr><td class="label">Status Pengujian</td><td>: 12 / 12 Skenario Berhasil (100% Lulus)</td></tr>
      </table>
    </div>

    <div class="cover-footer">
      Banjarmasin &bull; Semester Ganjil 2026/2027
    </div>
  </div>

  <!-- BAB 1 -->
  <h1>Bab 1: Analisis Kebutuhan dan Perancangan REST API</h1>

  <h2>1.1 Identifikasi Aktor dan Wewenang Sistem</h2>
  <p>Berdasarkan studi kasus Sistem Layanan Informasi dan Pengaduan Mahasiswa (SIMADU), sistem melibatkan dua aktor utama dengan batasan wewenang yang tegas:</p>
  <ul>
    <li><strong>Mahasiswa</strong>: Merupakan pengguna akhir (konsumen layanan) yang memiliki wewenang untuk mengajukan pengaduan baru, melihat riwayat pengaduan yang ia buat sendiri, serta mengubah atau membatalkan/menghapus pengaduan miliknya sendiri <em>hanya selama status pengaduan masih 'diajukan'</em>. Mahasiswa dilarang keras melihat atau memodifikasi pengaduan milik mahasiswa lain, dan dilarang mengubah status penanganan pengaduan.</li>
    <li><strong>Administrator Kampus</strong>: Merupakan pengelola layanan pengaduan kampus yang memiliki wewenang untuk memantau dan melihat seluruh pengaduan yang masuk dari seluruh mahasiswa, serta memperbarui status penanganan pengaduan (dari <code>diajukan</code> &rarr; <code>diproses</code> &rarr; <code>selesai</code>). Administrator tidak berhak membuat pengaduan mengatasnamakan mahasiswa, tidak dapat mengubah identitas pemilik pengaduan, dan tidak berhak mengubah substansi uraian pengaduan mahasiswa.</li>
  </ul>

  <h2>1.2 Resource Utama Sistem</h2>
  <p>Resource utama yang dikelola oleh SIMADU API adalah entitas <code>pengaduan</code>, yang didukung oleh sub-resource <code>auth</code> untuk manajemen sesi dan kredensial:</p>
  <ul>
    <li><code>/api/auth/login</code>: Pengelolaan autentikasi kredensial pengguna dan penerbitan Bearer Token JWT.</li>
    <li><code>/api/pengaduan</code>: Manajemen siklus hidup (CRUD) laporan pengaduan mahasiswa.</li>
  </ul>

  <h2>1.3 Tabel Kontrak Endpoint API</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 12%;">Metode</th>
        <th style="width: 28%;">Endpoint</th>
        <th style="width: 32%;">Fungsi & Hak Akses</th>
        <th style="width: 14%;">Sukses</th>
        <th style="width: 14%;">Gagal</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><span class="badge badge-post">POST</span></td>
        <td><code>/api/auth/login</code></td>
        <td>Autentikasi kredensial (NIM/Admin & Password). Mengembalikan JWT Bearer Token. Terbuka untuk umum.</td>
        <td>200 OK</td>
        <td>400, 401</td>
      </tr>
      <tr>
        <td><span class="badge badge-get">GET</span></td>
        <td><code>/api/pengaduan</code></td>
        <td>Mengambil daftar pengaduan. Mahasiswa: hanya miliknya; Admin: seluruh data kampus.</td>
        <td>200 OK</td>
        <td>401</td>
      </tr>
      <tr>
        <td><span class="badge badge-get">GET</span></td>
        <td><code>/api/pengaduan/:id</code></td>
        <td>Mengambil detail pengaduan. Mahasiswa hanya boleh mengakses miliknya (milik orang lain menghasilkan 403).</td>
        <td>200 OK</td>
        <td>400, 401, 403, 404</td>
      </tr>
      <tr>
        <td><span class="badge badge-post">POST</span></td>
        <td><code>/api/pengaduan</code></td>
        <td>Membuat pengaduan baru. Khusus role Mahasiswa. ID pemilik diambil otomatis dari token JWT.</td>
        <td>201 Created</td>
        <td>400, 401, 403</td>
      </tr>
      <tr>
        <td><span class="badge badge-put">PUT</span></td>
        <td><code>/api/pengaduan/:id</code></td>
        <td>Memperbarui judul, kategori, dan deskripsi. Khusus mahasiswa pemilik dan status masih <code>diajukan</code>.</td>
        <td>200 OK</td>
        <td>400, 401, 403, 404</td>
      </tr>
      <tr>
        <td><span class="badge badge-patch">PATCH</span></td>
        <td><code>/api/pengaduan/:id/status</code></td>
        <td>Memperbarui status penanganan laporan (diajukan/diproses/selesai). Khusus role Administrator.</td>
        <td>200 OK</td>
        <td>400, 401, 403, 404</td>
      </tr>
      <tr>
        <td><span class="badge badge-delete">DELETE</span></td>
        <td><code>/api/pengaduan/:id</code></td>
        <td>Menghapus pengaduan. Khusus mahasiswa pemilik dan hanya selama status masih <code>diajukan</code>.</td>
        <td>200 OK</td>
        <td>400, 401, 403, 404</td>
      </tr>
    </tbody>
  </table>

  <h2>1.4 Struktur JSON Request dan Response Standar</h2>
  <p>Sistem menerapkan format respons seragam (*consistent JSON envelope*) untuk menjamin prediktabilitas parsing oleh aplikasi consumer (Web dan Mobile):</p>
  <div class="code-box">
// Format Respons Sukses:
{
  "success": true,
  "message": "Deskripsi aksi berhasil",
  "data": { ... } // Objek tunggal atau array data
}

// Format Respons Error:
{
  "success": false,
  "message": "Pesan deskripsi kesalahan yang informatif tanpa membocorkan info internal"
}
  </div>

  <h2>1.5 Diagram Alur Komunikasi Consumer–Provider</h2>
  <div class="diagram-box">
+---------------------+         +----------------------+
|   Aplikasi Web      |         |   Aplikasi Mobile    |
| (Frontend Consumer) |         | (Flutter / React Nat)|
+----------+----------+         +----------+-----------+
           |                               |
           | HTTP/HTTPS JSON Request       | HTTP/HTTPS JSON Request
           | Header: Authorization: Bearer | Header: Authorization: Bearer
           +---------------+---------------+
                           |
                           v
        +-------------------------------------+
        |       SIMADU REST API PROVIDER      |
        |        (Node.js / Express 5)        |
        +-------------------------------------+
        |  Port 3000 | OpenAPI 3.0 Documented |
        +-------------------------------------+
  </div>

  <h2>1.6 Diagram Arsitektur Sistem Berlapis (Layered Architecture)</h2>
  <div class="diagram-box">
Incoming Request ---> [ Router Layer (routes/index.cjs, pengaduanRoutes.cjs) ]
                             |
                             v
                      [ Middleware Layer ]
                      ├── authMiddleware.cjs        (Verifikasi JWT Bearer Token)
                      ├── roleMiddleware.cjs        (Pengecekan Wewenang RBAC)
                      └── validationMiddleware.cjs  (Validasi Payload & Strict Whitelist)
                             |
                             v
                      [ Controller Layer (pengaduanController.cjs) ]
                      (HTTP Req/Res Parsing, Parameter Extraction, HTTP Status)
                             |
                             v
                      [ Service Layer (pengaduanService.cjs) ]
                      (Business Logic, State Invariant Rules, Data Ownership Check)
                             |
                             v
                      [ Repository Layer (pengaduanRepository.cjs) ]
                      (Data Access Layer, CRUD Operations, Thread-Safe In-Memory Store)
                             |
                             v
                      [ Centralized Error Handler (errorHandler.cjs) ]
                      (Tangkap exception, filter 500 error, kirim standar JSON)
  </div>

  <div class="page-break"></div>

  <!-- BAB 2 -->
  <h1>Bab 2: Implementasi Arsitektur REST API Berlapis</h1>

  <h2>2.1 Struktur Proyek SIMADU API</h2>
  <p>Implementasi kode disusun secara terstruktur mengikuti rekomendasi spesifikasi ujian:</p>
  <div class="code-box">
simadu-api/
├── src/
│   ├── controllers/         # authController.cjs, pengaduanController.cjs
│   ├── services/            # authService.cjs, pengaduanService.cjs
│   ├── repositories/        # userRepository.cjs, pengaduanRepository.cjs
│   ├── routes/              # index.cjs, authRoutes.cjs, pengaduanRoutes.cjs
│   └── middleware/          # authMiddleware.cjs, roleMiddleware.cjs, validationMiddleware.cjs, errorHandler.cjs
├── docs/
│   └── openapi.json         # Kontrak OpenAPI 3.0 Lengkap
├── tests/
│   ├── run12Scenarios.cjs   # Test suite otomatis 12 skenario pengujian
│   ├── generateScreenshots.cjs # Skrip penangkap bukti visual
│   └── results.json         # Hasil pengujian riil
├── screenshots/             # 13 Berkas PNG bukti pengujian aktual
├── app.cjs                  # Inisialisasi Express 5, CORS, middleware global, Swagger UI
├── server.cjs               # Listener HTTP server entry point
├── package.json             # Konfigurasi dependensi dan npm scripts
├── .env.example             # Konfigurasi environment template
├── .gitignore               # Berkas pengabaian version control
└── README.md                # Dokumentasi petunjuk penggunaan
  </div>

  <h2>2.2 Pembagian Tanggung Jawab Komponen</h2>
  <ul>
    <li><strong>Router Layer</strong>: Mengarahkan lalu lintas URL ke controller yang bersangkutan dan menerapkan *middleware pipeline* secara deklaratif. Contoh: <code>router.post('/', requireRole('mahasiswa'), validateCreatePengaduan, controller.create)</code>.</li>
    <li><strong>Middleware Layer</strong>: Bertindak sebagai pertahanan pertama. Memverifikasi keabsahan JWT, menolak peran yang tidak sah (RBAC), memblokir field request terlarang (seperti injeksi <code>mahasiswaId</code> atau <code>status</code> manual dari client), dan menangkap galat global.</li>
    <li><strong>Controller Layer</strong>: Mengambil input dari HTTP request (<code>req.body</code>, <code>req.params</code>, <code>req.user</code>), mendelegasikan ke service, dan mengembalikan respons HTTP beserta kode status (200, 201). Tidak mengandung logika bisnis database.</li>
    <li><strong>Service Layer</strong>: Inti kecerdasan sistem (*brain of the system*). Memvalidasi aturan kepemilikan data (mahasiswa hanya boleh mengubah/melihat laporannya sendiri) dan konsistensi status (pengaduan hanya boleh diubah jika status masih <code>diajukan</code>).</li>
    <li><strong>Repository Layer</strong>: Mengisolasi mekanisme penyimpanan data. Menggunakan representasi in-memory terstruktur dengan initial seed data yang mencakup dua mahasiswa dan satu administrator.</li>
  </ul>

  <!-- BAB 3 -->
  <h1>Bab 3: Penerapan Keamanan REST API</h1>

  <h2>3.1 Autentikasi dan Penyimpanan Password Terenkripsi</h2>
  <p>Sistem menolak penyimpanan password dalam format plaintext. Password seluruh pengguna disimpan dalam bentuk hash kriptografis satu arah menggunakan algoritma <strong>bcrypt</strong> dengan <em>cost factor</em> 10 rounds pada <code>userRepository.cjs</code>. Saat login di <code>authService.cjs</code>, verifikasi dilakukan dengan <code>bcrypt.compare()</code> sehingga nilai asli password tidak pernah diketahui oleh sistem basis data.</p>

  <h2>3.2 Bearer Token JWT dengan Mekanisme Kedaluwarsa</h2>
  <p>Setelah autentikasi berhasil, server menerbitkan token berformat <strong>JSON Web Token (JWT)</strong> yang ditandatangani secara kriptografis menggunakan algoritma HMAC-SHA256 (HS256) dengan secret key yang tersimpan di environment variable. Token menyertakan payload:</p>
  <div class="code-box">
{
  "sub": "240101",
  "nama": "Budi Santoso",
  "role": "mahasiswa",
  "prodi": "Teknologi Informasi",
  "iat": 1795409198,
  "exp": 1795412798  // Masa aktif tepat 1 jam (3600 detik)
}
  </div>

  <h2>3.3 Matriks Hak Akses (Role-Based Access Control)</h2>
  <table>
    <thead>
      <tr>
        <th>Operasi</th>
        <th>Metode & Endpoint</th>
        <th style="text-align:center;">Mahasiswa</th>
        <th style="text-align:center;">Admin</th>
        <th>Kebijakan Keamanan</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Melihat Pengaduan Sendiri</td>
        <td><code>GET /api/pengaduan/:id</code></td>
        <td style="text-align:center; color:green; font-weight:bold;">✓</td>
        <td style="text-align:center; color:green; font-weight:bold;">✓</td>
        <td>Mahasiswa dibatasi hanya ID miliknya; Admin dapat melihat siapa saja.</td>
      </tr>
      <tr>
        <td>Melihat Semua Pengaduan</td>
        <td><code>GET /api/pengaduan</code></td>
        <td style="text-align:center; color:red; font-weight:bold;">✗ (Hanya miliknya)</td>
        <td style="text-align:center; color:green; font-weight:bold;">✓ (Semua)</td>
        <td>Query mahasiswa difilter otomatis berdasarkan <code>req.user.sub</code>.</td>
      </tr>
      <tr>
        <td>Membuat Pengaduan</td>
        <td><code>POST /api/pengaduan</code></td>
        <td style="text-align:center; color:green; font-weight:bold;">✓</td>
        <td style="text-align:center; color:red; font-weight:bold;">✗</td>
        <td>Admin dilarang membuat pengaduan mengatasnamakan mahasiswa.</td>
      </tr>
      <tr>
        <td>Mengubah Pengaduan Sendiri</td>
        <td><code>PUT /api/pengaduan/:id</code></td>
        <td style="text-align:center; color:green; font-weight:bold;">✓ (Hanya 'diajukan')</td>
        <td style="text-align:center; color:red; font-weight:bold;">✗</td>
        <td>Ditolak 403 jika status sudah <code>diproses</code> atau <code>selesai</code>.</td>
      </tr>
      <tr>
        <td>Menghapus Pengaduan Sendiri</td>
        <td><code>DELETE /api/pengaduan/:id</code></td>
        <td style="text-align:center; color:green; font-weight:bold;">✓ (Hanya 'diajukan')</td>
        <td style="text-align:center; color:red; font-weight:bold;">✗</td>
        <td>Ditolak 403 jika status bukan <code>diajukan</code>.</td>
      </tr>
      <tr>
        <td>Mengubah Status Pengaduan</td>
        <td><code>PATCH /api/pengaduan/:id/status</code></td>
        <td style="text-align:center; color:red; font-weight:bold;">✗ (403 Forbidden)</td>
        <td style="text-align:center; color:green; font-weight:bold;">✓</td>
        <td>Hanya Administrator yang berwenang memproses status laporan.</td>
      </tr>
    </tbody>
  </table>

  <h2>3.4 Validasi Input Ketat dan Penanganan Error Terpusat</h2>
  <p>Pencegahan manipulasi data (*Mass Assignment Vulnerability*) diterapkan secara ketat pada <code>validationMiddleware.cjs</code>:</p>
  <ul>
    <li>Field <code>id</code>, <code>mahasiswaId</code>, <code>status</code>, dan <code>createdAt</code> dilarang dikirimkan oleh client pada endpoint pembuatan dan pengubahan pengaduan. Jika terdeteksi, server langsung mengembalikan <code>400 Bad Request</code>.</li>
    <li>Nilai enum untuk <code>kategori</code> dibatasi secara tegas pada <code>['Fasilitas', 'Akademik', 'TI']</code>.</li>
    <li>Parameter URL <code>:id</code> divalidasi harus berupa bilangan bulat positif.</li>
    <li>Error Handler terpusat memastikan error 400, 401, 403, dan 404 mengembalikan format JSON yang konsisten, sedangkan error level 500 disamarkan pesannya agar tidak membocorkan informasi tumpukan kode (*stack trace leak*) ke publik.</li>
  </ul>

  <div class="page-break"></div>

  <!-- BAB 4 -->
  <h1>Bab 4: Dokumentasi OpenAPI dan Swagger UI</h1>
  <p>SIMADU API dilengkapi dengan dokumen spesifikasi OpenAPI 3.0.3 lengkap pada berkas <code>docs/openapi.json</code>. Dokumentasi ini terintegrasi langsung pada server Express menggunakan <code>swagger-ui-express</code> dan dapat diakses secara visual dan interaktif melalui peramban pada alamat <code>http://localhost:3000/api-docs</code>.</p>

  <div class="screenshot-container">
    <img src="${swaggerBase64}" alt="Dokumentasi Swagger UI Interaktif SIMADU REST API">
    <div class="screenshot-caption">Gambar 4.1: Tampilan Dokumentasi Interaktif Swagger UI SIMADU API pada Endpoint /api-docs</div>
  </div>

  <div class="page-break"></div>

  <!-- BAB 5 -->
  <h1>Bab 5: Pengujian Fungsional dan Keamanan</h1>

  <h2>5.1 Rekapitulasi Hasil 12 Skenario Pengujian Wajib</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 5%;">No</th>
        <th style="width: 32%;">Skenario Pengujian</th>
        <th style="width: 15%;">Metode & URL</th>
        <th style="width: 16%;">Hasil Harapan</th>
        <th style="width: 16%;">Hasil Aktual</th>
        <th style="width: 16%;">Status Uji</th>
      </tr>
    </thead>
    <tbody>
      ${scenarioDetails.map(s => `
      <tr>
        <td style="text-align:center; font-weight:bold;">${s.no}</td>
        <td><strong>${s.title}</strong><br><span style="font-size:8.5pt; color:#4a5568;">${s.desc}</span></td>
        <td><code>${s.method} ${s.endpoint}</code></td>
        <td><code>${s.expected}</code></td>
        <td><code>${s.actual}</code></td>
        <td style="text-align:center;"><span class="badge badge-pass">&#10004; ${s.status}</span></td>
      </tr>
      `).join('')}
    </tbody>
  </table>

  <h2>5.2 Bukti Eksekusi Terminal Test Suite (CLI)</h2>
  <div class="screenshot-container">
    <img src="${terminalBase64}" alt="Bukti Eksekusi Suite Pengujian Otomatis 12 Skenario">
    <div class="screenshot-caption">Gambar 5.1: Bukti Eksekusi Terminal CLI (12 dari 12 Skenario Pengujian Lulus 100%)</div>
  </div>

  <div class="page-break"></div>

  <h2>5.3 Bukti Screenshot Respons Aktual Setiap Skenario Pengujian</h2>
  <p>Berikut adalah bukti tangkapan layar respons server riil yang memperlihatkan request header, request body, kode status HTTP, serta respons body JSON aktual untuk masing-masing skenario:</p>

  ${scenarioDetails.map(s => `
  <div class="screenshot-container" style="margin-bottom: 25px;">
    <h3 style="text-align:left; color:#1a365d; margin-top:0;">Skenario ${s.no}: ${s.title} (${s.expected})</h3>
    <img src="${scenariosBase64[s.no]}" alt="Screenshot Skenario ${s.no}">
    <div class="screenshot-caption">Bukti Respons Aktual Skenario ${s.no}: ${s.method} ${s.endpoint} &rarr; Status Aktual: ${s.actual}</div>
  </div>
  ${s.no % 2 === 0 && s.no !== 12 ? '<div class="page-break"></div>' : ''}
  `).join('')}

  <div class="page-break"></div>

  <!-- BAB 6 -->
  <h1>Bab 6: Jawaban 10 Pertanyaan Demonstrasi</h1>
  <p>Bagian ini menyajikan pertanggungjawaban teknis atas 10 pertanyaan evaluasi pemahaman individual, yang disusun secara mendalam dengan merujuk langsung pada implementasi kode sumber proyek SIMADU API.</p>

  <!-- Q1 -->
  <div class="qa-box">
    <div class="qa-question">1. Apa perbedaan autentikasi dan otorisasi? Tunjukkan implementasinya di dalam kode.</div>
    <div class="qa-answer">
      <p><strong>Autentikasi (Authentication - "Who are you?")</strong> adalah proses memverifikasi identitas entitas yang mengaku memiliki hak di sistem. Di dalam kode SIMADU API, autentikasi diimplementasikan pada:</p>
      <ul>
        <li><code>src/services/authService.cjs</code>: Memverifikasi ID pengguna dan mencocokkan password plaintext dengan hash menggunakan <code>await bcrypt.compare(password, user.passwordHash)</code>, lalu menerbitkan JWT Bearer Token.</li>
        <li><code>src/middleware/authMiddleware.cjs</code>: Membaca header <code>Authorization: Bearer &lt;token&gt;</code> dan memverifikasi tanda tangan digital token menggunakan <code>jwt.verify(token, secretKey)</code>, kemudian menyematkan data identitas ke <code>req.user</code>.</li>
      </ul>
      <p><strong>Otorisasi (Authorization - "What are you allowed to do?")</strong> adalah proses penentuan apakah pengguna yang sudah terotentikasi berhak menjalankan aksi tertentu pada sumber daya yang diminta. Implementasinya:</p>
      <ul>
        <li><code>src/middleware/roleMiddleware.cjs</code>: Melakukan pembatasan berbasis peran (RBAC), misalnya memastikan hanya peran <code>admin</code> yang boleh mengakses endpoint pengubahan status (<code>requireRole('admin')</code>), sedangkan peran <code>mahasiswa</code> ditolak dengan status <code>403 Forbidden</code>.</li>
        <li><code>src/services/pengaduanService.cjs</code>: Melakukan otorisasi tingkat data (*Data Ownership*), memeriksa <code>if (pengaduan.mahasiswaId !== user.sub) throw 403</code>, memastikan mahasiswa tidak dapat membaca, mengubah, atau menghapus pengaduan mahasiswa lain meskipun sama-sama berstatus mahasiswa terdaftar.</li>
      </ul>
    </div>
  </div>

  <!-- Q2 -->
  <div class="qa-box">
    <div class="qa-question">2. Mengapa mahasiswa yang berhasil login belum tentu boleh mengakses semua endpoint?</div>
    <div class="qa-answer">
      <p>Keberhasilan login hanya membuktikan bahwa akun pengguna terdaftar secara sah di sistem (*valid identity*), bukan berarti pengguna tersebut memegang wewenang penuh tanpa batas. Sistem mengadopsi prinsip <strong>Least Privilege</strong> (hak akses minimal), di mana setiap peran hanya diizinkan menjalankan fungsi yang relevan dengan tugasnya:</p>
      <ul>
        <li>Mahasiswa hanya bertindak sebagai pelapor (*reporter*), sehingga wewenangnya dibatasi pada pengaduan miliknya sendiri. Jika mahasiswa diizinkan mengakses semua endpoint, mahasiswa bisa melihat rahasia aduan rekan lainnya atau bahkan menyetujui/mengubah status laporannya sendiri menjadi 'selesai' tanpa verifikasi kampus.</li>
        <li>Endpoint seperti <code>PATCH /api/pengaduan/:id/status</code> merupakan hak prerogatif Administrator kampus yang bertanggung jawab atas tindak lanjut operasional fasilitas. Oleh karena itu, otorisasi RBAC membatasi mahasiswa agar tidak menyalahgunakan fungsi administratif.</li>
      </ul>
    </div>
  </div>

  <!-- Q3 -->
  <div class="qa-box">
    <div class="qa-question">3. Apa perbedaan respons HTTP 401 dan 403?</div>
    <div class="qa-answer">
      <p>Perbedaan mendasar terletak pada aspek identitas versus wewenang:</p>
      <ul>
        <li><strong>HTTP 401 Unauthorized (Tepatnya: Unauthenticated)</strong>: Menandakan bahwa server tidak mengetahui siapa klien tersebut karena kredensial otentikasi tidak disediakan, format token salah, tanda tangan JWT rusak, atau token telah kedaluwarsa. Klien dapat mengulang permintaan yang sama jika menyertakan token/kredensial yang benar.</li>
        <li><strong>HTTP 403 Forbidden (Authenticated, but Not Authorized)</strong>: Menandakan bahwa server <em>sudah mengenali identitas klien secara valid</em> (klien telah login dan token sah), tetapi server <em>menolak memberikan izin</em> untuk melakukan operasi tersebut. Mengirimkan ulang token yang sama tidak akan mengubah hasil karena klien memang tidak memiliki hak istimewa atas data atau endpoint tersebut.</li>
      </ul>
    </div>
  </div>

  <!-- Q4 -->
  <div class="qa-box">
    <div class="qa-question">4. Bagaimana API memastikan seorang mahasiswa hanya dapat mengubah pengaduannya sendiri?</div>
    <div class="qa-answer">
      <p>API menerapkan strategi pengamanan berlapis:</p>
      <ol>
        <li><strong>Identitas Tepercaya Berasal dari Token (Bukan Client Body)</strong>: Sistem tidak mempercayai parameter pemilik yang dikirim klien. Nilai <code>mahasiswaId</code> diperoleh secara internal dari klaim <code>req.user.sub</code> pada JWT yang telah diotentikasi oleh server. Bahkan <code>validationMiddleware</code> akan menolak request jika client mencoba mengirimkan body berisi <code>mahasiswaId</code>.</li>
        <li><strong>Pengecekan Kepemilikan pada Service Layer</strong>: Pada berkas <code>src/services/pengaduanService.cjs</code> method <code>updatePengaduan()</code>, sistem mencari data pengaduan yang bersangkutan di repository berdasarkan ID, lalu membandingkan ID pemilik:
          <div class="code-box">if (pengaduan.mahasiswaId !== user.sub) {
  const err = new Error('Akses ditolak: Anda bukan pemilik dari pengaduan ini');
  err.statusCode = 403;
  throw err;
}</div>
        </li>
        <li><strong>Invarian Status Laporan</strong>: Selain verifikasi kepemilikan, service memeriksa apakah status masih <code>diajukan</code>. Jika pengaduan sudah <code>diproses</code> atau <code>selesai</code>, perubahan tetap ditolak dengan 403 untuk menjaga integritas investigasi kampus.</li>
      </ol>
    </div>
  </div>

  <!-- Q5 -->
  <div class="qa-box">
    <div class="qa-question">5. Mengapa password harus di-hash dan mengapa token tidak boleh dicatat ke log?</div>
    <div class="qa-answer">
      <p><strong>Alasan Password Wajib Di-hash</strong>:</p>
      <ul>
        <li>Mencegah risiko kebocoran data (*data breach*). Jika basis data dicuri atau terekspos akibat *SQL Injection* atau *unauthorized dump*, password tidak dapat dibaca oleh peretas.</li>
        <li>Penggunaan fungsi hash adaptif dengan *salt* unik (seperti <code>bcrypt</code> pada <code>userRepository.cjs</code>) menjamin nilai hash bersifat satu arah (*one-way*), memperlambat serangan *brute force*, dan kebal terhadap pencocokan kamus (*rainbow tables*). Hal ini melindungi pengguna yang sering menggunakan password yang sama pada layanan lain (*credential stuffing prevention*).</li>
      </ul>
      <p><strong>Alasan Token Tidak Boleh Dicatat ke Log (No Token Logging)</strong>:</p>
      <ul>
        <li>Bearer Token adalah *bearer credential* (kredensial pembawa). Siapa pun yang memegang token tersebut dapat melakukan aksi atas nama pengguna (*identity theft/session hijacking*) tanpa memerlukan password.</li>
        <li>File log server (seperti <code>access.log</code>, output ELK Stack, atau APM) sering kali diakses oleh banyak pihak (tim DevOps, analis sistem, penyedia layanan analitik pihak ketiga) dan sering disimpan dalam bentuk teks biasa tanpa enkripsi ketat. Jika token dicatat dalam log, kebocoran berkas log sama berbahayanya dengan kebocoran sesi login pengguna.</li>
      </ul>
    </div>
  </div>

  <!-- Q6 -->
  <div class="qa-box">
    <div class="qa-question">6. Bagaimana sebuah input yang salah ditangani oleh middleware dan error handler?</div>
    <div class="qa-answer">
      <p>Sistem menangani input yang salah melalui pipa terstruktur (*middleware pipeline*):</p>
      <ol>
        <li><strong>Parsing JSON Request</strong>: <code>express.json()</code> memeriksa sintaks JSON. Jika JSON malformed/rusak, ditangkap oleh <code>errorHandler.cjs</code> dan mengembalikan <code>400 Bad Request</code>.</li>
        <li><strong>Validasi Field Terlarang & Field Tak Dikenal</strong>: Di <code>validationMiddleware.cjs</code>, sistem memeriksa apakah ada upaya pengiriman atribut ilegal seperti <code>id</code>, <code>mahasiswaId</code>, atau <code>status</code>. Jika ada, request langsung diputus (*early exit*) dengan respons 400.</li>
        <li><strong>Validasi Field Wajib & Nilai Enum</strong>: Memeriksa apakah <code>judul</code>, <code>kategori</code>, atau <code>deskripsi</code> kosong atau hanya berupa spasi, serta memastikan kategori termasuk dalam <code>['Fasilitas', 'Akademik', 'TI']</code>. Jika tidak sesuai, dikembalikan respons 400 disertai pesan spesifik.</li>
        <li><strong>Centralized Error Handler</strong>: Setiap error yang dilempar dari controller/service diteruskan ke <code>errorHandler.cjs</code> melalui <code>next(err)</code>. Middleware ini memformat respons JSON secara konsisten: <code>{ "success": false, "message": err.message }</code> dengan kode status yang tepat (400, 401, 403, 404), serta menyamarkan error 500 tanpa membocorkan tumpukan memori/kode.</li>
      </ol>
    </div>
  </div>

  <!-- Q7 -->
  <div class="qa-box">
    <div class="qa-question">7. Apa perbedaan HTTPS dengan autentikasi Bearer Token?</div>
    <div class="qa-answer">
      <p>Keduanya beroperasi pada lapisan yang berbeda dalam model jaringan dan memiliki peran yang saling melengkapi:</p>
      <ul>
        <li><strong>HTTPS (Lapisan Transport / TLS)</strong>: Mengamankan saluran transmisi data antara klien dan server. Menjamin <em>Kerahasiaan</em> (data terenkripsi end-to-end), <em>Integritas</em> (mencegah manipulasi paket data oleh pihak ketiga/MITM), dan <em>Otentisitas Server</em> (memastikan klien terhubung ke domain kampus yang asli melalui sertifikat digital SSL/TLS).</li>
        <li><strong>Bearer Token (Lapisan Aplikasi / HTTP Authorization)</strong>: Mengidentifikasi subjek pengguna dan mengelola otorisasi hak akses di dalam logika perangkat lunak aplikasi secara *stateless*.</li>
      </ul>
      <p><strong>Hubungan Keduanya</strong>: Bearer Token <em>tidak menggantikan</em> HTTPS dan <em>sangat bergantung</em> padanya. Jika Bearer Token dikirim melalui protokol HTTP biasa tanpa enkripsi TLS, penyerang yang berada pada jaringan lokal (misal Wi-Fi kampus) dapat menyadap (*packet sniffing*) token tersebut dalam bentuk plain text dan membajak akun pengguna. Sebaliknya, HTTPS melindungi kerahasiaan token tersebut saat transit di jaringan.</p>
    </div>
  </div>

  <!-- Q8 -->
  <div class="qa-box">
    <div class="qa-question">8. Bagaimana membuktikan bahwa input yang ditolak tidak mengubah data?</div>
    <div class="qa-answer">
      <p>Pembuktian dilakukan melalui metodologi <strong>State Invariance Verification</strong> (verifikasi keadaan sebelum dan sesudah permintaan ditolak):</p>
      <ol>
        <li><strong>Snapshot Awal (Pre-condition)</strong>: Lakukan pemanggilan <code>GET /api/pengaduan/1</code> untuk mencatat nilai status, judul, dan waktu pembaruan (misal: ID 1 berstatus <code>diajukan</code> dan judul "AC Ruang Lab Komputer 2 Tidak Dingin").</li>
        <li><strong>Injeksi Request Tidak Sah (Trigger Rejection)</strong>: Kirimkan request yang melanggar aturan, contohnya:
          <ul>
            <li>Mahasiswa mengirimkan <code>PATCH /api/pengaduan/1/status</code> berisi <code>{"status": "selesai"}</code> (Ditolak dengan <code>403 Forbidden</code>).</li>
            <li>Atau mahasiswa mengirimkan <code>PUT /api/pengaduan/1</code> dengan body kosong atau field judul string kosong <code>{"judul": ""}</code> (Ditolak dengan <code>400 Bad Request</code>).</li>
          </ul>
        </li>
        <li><strong>Pemeriksaan Pasca-Penolakan (Post-condition)</strong>: Panggil kembali <code>GET /api/pengaduan/1</code>. Hasil pembacaan membuktikan bahwa data tetap utuh 100% tanpa ada perubahan atribut apa pun.</li>
      </ol>
      <p>Hal ini terjadi karena arsitektur middleware dan service menerapkan pola <em>Fail-Fast</em>: validasi dieksekusi terlebih dahulu sebelum alur program menyentuh fungsi mutasi pada repository, sehingga operasi bersifat atomik.</p>
    </div>
  </div>

  <!-- Q9 -->
  <div class="qa-box">
    <div class="qa-question">9. Mengapa dokumentasi Swagger yang tampil belum cukup membuktikan API berjalan dengan benar?</div>
    <div class="qa-answer">
      <p>Dokumentasi Swagger UI hanyalah representasi visual dari berkas kontrak statis (<code>openapi.json</code>). Keberadaan Swagger UI hanya membuktikan bahwa pengembang telah mendefinisikan *skema deklaratif* tentang bagaimana antarmuka API seharusnya bekerja, bukan bukti bahwa sistem berjalan secara fungsional.</p>
      <p>Swagger UI yang tampil sempurna bisa saja memiliki kelemahan berikut jika tidak diuji:</p>
      <ul>
        <li>Kode di balik controller belum terhubung ke database atau hanya mengembalikan data tiruan (*mock/dummy response*).</li>
        <li>Aturan otorisasi kepemilikan data tidak diterapkan, sehingga pengguna masih bisa mengakses data pengguna lain.</li>
        <li>Validasi input bocor, memungkinkan client menyuntikkan field ilegal yang merusak integritas sistem.</li>
      </ul>
      <p>Oleh karena itu, pembuktian keabsahan sistem <strong>wajib dilakukan melalui eksekusi pengujian dinamis</strong> (seperti 12 skenario pengujian pada Bab 5), yang memverifikasi bahwa respons aktual (baik status 200/201 maupun penolakan 400/401/403/404) benar-benar ditegakkan oleh server secara konsisten.</p>
    </div>
  </div>

  <!-- Q10 -->
  <div class="qa-box">
    <div class="qa-question">10. Apa yang harus diperbaiki agar layanan ini layak diterapkan pada lingkungan produksi (Production Readiness)?</div>
    <div class="qa-answer">
      <p>Untuk menaikkan tingkat kematangan SIMADU API ke standar produksi industri (*enterprise production grade*), berikut rekomendasi perbaikan teknis yang harus diterapkan:</p>
      <ol>
        <li><strong>Penyimpanan Data Permanen (Persistent Database)</strong>: Mengganti penyimpanan array in-memory dengan Database Relasional Enterprise (seperti PostgreSQL atau MySQL) yang mendukung transaksi ACID, indeks performa, dan migrasi skema menggunakan ORM/Query Builder seperti Prisma atau Knex.js.</li>
        <li><strong>Proteksi Rate Limiting & Brute-Force</strong>: Memasang middleware <code>express-rate-limit</code> dan Redis untuk membatasi frekuensi request, khususnya pada endpoint <code>/api/auth/login</code> (misalnya maksimal 5 percobaan login gagal per 15 menit) guna mencegah serangan *credential stuffing* dan *Denial of Service (DoS)*.</li>
        <li><strong>Mekanisme Refresh Token dan Pencabutan Sesi (Token Revocation)</strong>: Menerapkan pola dual-token (Access Token berumur pendek ~15 menit dan Refresh Token berumur 7 hari yang disimpan dalam cookie HttpOnly bersertifikat Secure). Menyediakan blacklist token di Redis untuk memungkinkan logout seketika atau pembatalan sesi saat kata sandi diganti.</li>
        <li><strong>Keamanan Header HTTP & TLS Wajib</strong>: Memasang library <code>helmet</code> untuk menyuntikkan header keamanan standar (seperti Content-Security-Policy, X-Frame-Options, HSTS), serta mewajibkan koneksi TLS 1.3 (HTTPS).</li>
        <li><strong>Sistem Logging Terstruktur & Monitoring (APM)</strong>: Mengintegrasikan logger terstruktur seperti <code>Pino</code> atau <code>Winston</code> yang memiliki filter sensor otomatis terhadap data sensitif (PII masking), serta menghubungkannya ke sistem observabilitas seperti Prometheus, Grafana, atau Sentry untuk pelaporan galat waktu nyata.</li>
        <li><strong>Pipeline Otomatisasi CI/CD & Automated Testing</strong>: Mengintegrasikan skrip pengujian (Jest/Supertest) ke dalam pipeline GitHub Actions agar setiap pembaruan kode diuji secara otomatis sebelum di-deploy ke klaster kontainer Docker/Kubernetes.</li>
      </ol>
    </div>
  </div>

  <!-- BAB 7 -->
  <h1>Bab 7: Kesimpulan</h1>
  <p>Pengembangan Sistem Layanan Informasi dan Pengaduan Mahasiswa (SIMADU REST API) telah berhasil diselesaikan dengan memenuhi seluruh kriteria teknis yang dipersyaratkan pada Ujian Tengah Semester mata kuliah Web Service Engineering:</p>
  <ul>
    <li>Arsitektur REST API berlapis telah diimplementasikan secara bersih dan terstruktur dengan pemisahan tanggung jawab yang tegas antara Router, Middleware, Controller, Service, dan Repository.</li>
    <li>Mekanisme keamanan enterprise telah diterapkan meliputi enkripsi password dengan hash bcrypt, manajemen sesi stateless berbasis Bearer Token JWT dengan kedaluwarsa 1 jam, kontrol otorisasi peran (RBAC) dan kepemilikan data (Data Ownership Authorization), serta penolakan ketat terhadap field ilegal.</li>
    <li>Dokumentasi API lengkap menggunakan standar OpenAPI 3.0 dan antarmuka Swagger UI interaktif telah tersedia pada endpoint <code>/api-docs</code>.</li>
    <li>Seluruh 12 skenario pengujian fungsional dan keamanan berhasil dieksekusi dengan tingkat kelulusan 100%, disertai dengan bukti screenshot respons aktual dan pertanggungjawaban teknis atas 10 pertanyaan demonstrasi.</li>
  </ul>

</body>
</html>`;

fs.writeFileSync(TEMP_HTML, htmlContent, 'utf-8');
console.log('Menghasilkan berkas PDF Laporan UTS menggunakan Google Chrome headless...');

try {
  execSync(`"${CHROME_PATH}" --headless=new --print-to-pdf="${OUT_PDF_ROOT}" --no-pdf-header-footer "${TEMP_HTML}"`);
  console.log('✓ Berhasil membuat PDF di Root Workspace:', OUT_PDF_ROOT);

  fs.copyFileSync(OUT_PDF_ROOT, OUT_PDF_SIMADU);
  console.log('✓ Berhasil menyalin PDF ke Folder simadu-api:', OUT_PDF_SIMADU);
} catch (err) {
  console.error('Gagal membuat PDF:', err.message);
} finally {
  if (fs.existsSync(TEMP_HTML)) fs.unlinkSync(TEMP_HTML);
}
