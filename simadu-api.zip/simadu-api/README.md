# SIMADU REST API
### Sistem Layanan Informasi dan Pengaduan Mahasiswa
> **Ujian Tengah Semester (UTS) - Web Service Engineering**  
> Program Studi Teknologi Informasi | UIN Antasari Banjarmasin  
> Dosen Pengampu: Muhayat, M.IT

---

## 1. Deskripsi Proyek
SIMADU REST API adalah layanan backend berbasis web service arsitektur RESTful yang dirancang untuk menangani pengaduan dan keluhan mahasiswa (fasilitas kampus, akademik, dan teknologi informasi) secara terintegrasi antara aplikasi web dan aplikasi mobile. 

Sistem ini menerapkan standar keamanan enterprise meliputi **Autentikasi Bearer JWT**, **Password Hashing (bcrypt)**, **Role-Based Access Control (RBAC)**, **Validasi Input Ketat (Disallow Unknown/Illegal Fields)**, serta **Dokumentasi Interaktif OpenAPI 3.0 & Swagger UI**.

---

## 2. Prasyarat Sistem (Prerequisites)
Sebelum menjalankan proyek, pastikan perangkat Anda telah terinstal:
- **Node.js**: Versi 18.x, 20.x, atau 22+ (Teruji optimal pada Node.js v24.21.0)
- **NPM**: Versi 9.x atau lebih baru (Teruji pada NPM v11.19.0)
- **Web Browser**: Google Chrome / Microsoft Edge / Mozilla Firefox untuk mengakses Swagger UI
- **HTTP Client (Opsional)**: Postman, Thunder Client, Insomnia, atau cURL

---

## 3. Instalasi dan Setup Proyek

### A. Clone atau Buka Folder Proyek
```bash
cd simadu-api
```

### B. Pasang Dependensi
Jalankan perintah berikut untuk menginstal seluruh dependensi yang dibutuhkan:
```bash
npm install
```
Dependensi utama yang digunakan:
- `express` (^5.3.0) — Web framework REST API modern
- `jsonwebtoken` (^9.0.3) — Manajemen penerbitan dan verifikasi Bearer Token JWT
- `bcryptjs` (^3.0.3) — Hashing password dengan algoritma Blowfish salt rounds 10
- `swagger-ui-express` (^5.0.1) — GUI dokumentasi OpenAPI 3.0 interaktif
- `dotenv` (^17.3.1) — Manajemen konfigurasi environment variable
- `cors` (^2.8.5) — Konfigurasi Cross-Origin Resource Sharing

### C. Konfigurasi Environment Variable
Salin file `.env.example` menjadi `.env`:
```bash
cp .env.example .env
```
Isi konfigurasi pada file `.env`:
```env
PORT=3000
NODE_ENV=development
JWT_SECRET=uts_wse_simadu_secret_key_uin_antasari_20261
JWT_EXPIRES_IN=1h
```

---

## 4. Cara Menjalankan Server

### Mode Produksi / Standar
```bash
npm start
```
Server akan aktif di: `http://localhost:3000`

### Mode Development (Hot Reload / Watch)
```bash
npm run dev
```

### Akses Dokumentasi Swagger UI
Buka peramban (browser) dan akses:
```
http://localhost:3000/api-docs
```

---

## 5. Struktur Direktori dan Arsitektur Berlapis

Proyek ini mengadopsi arsitektur berlapis (*layered architecture*) dengan pemisahan tanggung jawab (*separation of concerns*) yang jelas:

```
simadu-api/
├── src/
│   ├── controllers/         # Menangani HTTP request, response parsing, dan status code
│   │   ├── authController.cjs
│   │   └── pengaduanController.cjs
│   ├── services/            # Logika bisnis inti, validasi domain, dan aturan otorisasi kepemilikan
│   │   ├── authService.cjs
│   │   └── pengaduanService.cjs
│   ├── repositories/        # Abstraksi akses data (Data Access Layer)
│   │   ├── userRepository.cjs
│   │   └── pengaduanRepository.cjs
│   ├── routes/              # Definisi endpoint URI, metode HTTP, dan binding middleware
│   │   ├── index.cjs
│   │   ├── authRoutes.cjs
│   │   └── pengaduanRoutes.cjs
│   └── middleware/          # Filter otentikasi token, RBAC, validasi schema, dan error handler
│       ├── authMiddleware.cjs
│       ├── roleMiddleware.cjs
│       ├── validationMiddleware.cjs
│       └── errorHandler.cjs
├── docs/
│   └── openapi.json         # Spesifikasi kontrak API standar OpenAPI 3.0
├── tests/
│   ├── run12Scenarios.cjs   # Skrip pengujian otomatis 12 skenario wajib
│   ├── generateScreenshots.cjs # Skrip otomatis penangkap screenshot respons aktual
│   └── results.json         # Hasil pencatatan pengujian aktual
├── screenshots/             # Bukti tangkapan layar pengujian aktual (PNG)
├── app.cjs                  # Konfigurasi aplikasi Express dan mounting middleware
├── server.cjs               # Entry point listener server HTTP
├── package.json             # Manifes dependensi dan npm scripts
├── .env.example             # Template konfigurasi environment
├── .gitignore               # Konfigurasi berkas yang diabaikan git
└── README.md                # Dokumentasi teknis proyek
```

### Pembagian Tanggung Jawab Komponen:
1. **Router (`src/routes/`)**: Bertanggung jawab menerima request HTTP dari client, memetakan path URI dan method (GET, POST, PUT, PATCH, DELETE), serta merangkai pipa middleware yang harus dilalui sebelum sampai ke controller.
2. **Middleware (`src/middleware/`)**: Berfungsi sebagai penjaga gerbang (*gatekeeper*). Memeriksa Bearer Token JWT (`authMiddleware`), memastikan otorisasi role (`roleMiddleware`), memvalidasi tipe/field/enum payload request (`validationMiddleware`), dan menangkap eksepsi aplikasi secara terpusat (`errorHandler`).
3. **Controller (`src/controllers/`)**: Bertindak sebagai adaptor protokol HTTP. Mengekstrak data dari `req.body`, `req.params`, dan `req.user`, memanggil service yang sesuai, lalu memformat payload respons JSON beserta status HTTP yang tepat.
4. **Service (`src/services/`)**: Mengandung seluruh logika bisnis (*business logic*), evaluasi kondisi status pengaduan (misal: pengaduan hanya boleh diubah/dihapus saat berstatus 'diajukan'), dan otorisasi kepemilikan data (mahasiswa dilarang membaca atau mengutak-atik pengaduan milik mahasiswa lain).
5. **Repository (`src/repositories/`)**: Bertanggung jawab murni atas persistensi data. Melakukan operasi CRUD pada *data store* tanpa mengetahui aturan bisnis maupun protokol HTTP.

---

## 6. Akun Uji Coba Awal (Seed Data)

Sistem telah dilengkapi dengan data uji awal yang mencakup 2 mahasiswa dan 1 administrator:

| ID / Username | Nama Lengkap | Role | Password Plaintext | Status Password di Sistem |
| :--- | :--- | :--- | :--- | :--- |
| **`240101`** | Budi Santoso | `mahasiswa` | `Password123!` | Hashed (bcrypt salt rounds 10) |
| **`240102`** | Siti Rahma | `mahasiswa` | `Password123!` | Hashed (bcrypt salt rounds 10) |
| **`admin01`** | Pak Joko (Admin) | `admin` | `AdminPassword123!` | Hashed (bcrypt salt rounds 10) |

---

## 7. Matriks Hak Akses (Authorization Matrix)

| Operasi API | Method & Endpoint | Mahasiswa | Administrator | Aturan Khusus |
| :--- | :--- | :---: | :---: | :--- |
| **Login** | `POST /api/auth/login` | :heavy_check_mark: | :heavy_check_mark: | Terbuka untuk umum |
| **Melihat Pengaduan Sendiri** | `GET /api/pengaduan/:id` | :heavy_check_mark: | :heavy_check_mark: | Hanya data ID miliknya |
| **Melihat Semua Pengaduan** | `GET /api/pengaduan` | :x: (Hanya miliknya) | :heavy_check_mark: (Seluruh data) | Mahasiswa difilter otomatis |
| **Membuat Pengaduan** | `POST /api/pengaduan` | :heavy_check_mark: | :x: | MahasiswaId dari JWT token |
| **Mengubah Pengaduan Sendiri** | `PUT /api/pengaduan/:id` | :heavy_check_mark: | :x: | Hanya jika status = `diajukan` |
| **Menghapus Pengaduan Sendiri**| `DELETE /api/pengaduan/:id`| :heavy_check_mark: | :x: | Hanya jika status = `diajukan` |
| **Mengubah Status Pengaduan** | `PATCH /api/pengaduan/:id/status` | :x: (403 Forbidden) | :heavy_check_mark: | Status: diajukan/diproses/selesai |

---

## 8. Kontrak Endpoint API

| Metode | Endpoint | Fungsi | Status Berhasil | Status Gagal |
| :--- | :--- | :--- | :---: | :---: |
| **POST** | `/api/auth/login` | Autentikasi kredensial pengguna & terbitkan JWT | `200 OK` | `400`, `401` |
| **GET** | `/api/pengaduan` | Mengambil daftar pengaduan sesuai peran | `200 OK` | `401` |
| **GET** | `/api/pengaduan/:id` | Mengambil rincian detail satu pengaduan | `200 OK` | `400`, `401`, `403`, `404` |
| **POST** | `/api/pengaduan` | Mengajukan laporan/keluhan mahasiswa baru | `201 Created` | `400`, `401`, `403` |
| **PUT** | `/api/pengaduan/:id` | Memperbarui judul, kategori, dan deskripsi | `200 OK` | `400`, `401`, `403`, `404` |
| **PATCH**| `/api/pengaduan/:id/status` | Memperbarui status penanganan laporan | `200 OK` | `400`, `401`, `403`, `404` |
| **DELETE**| `/api/pengaduan/:id` | Menghapus pengaduan yang belum diproses | `200 OK` | `400`, `401`, `403`, `404` |

---

## 9. Menjalankan Pengujian Otomatis

Proyek ini menyertakan suite pengujian otomatis yang menguji seluruh 12 skenario wajib:
```bash
npm test
```

Untuk mengenerate ulang seluruh bukti screenshot aktual ke dalam folder `screenshots/`:
```bash
npm run generate-screenshots
```

Semua 12 skenario pengujian diuji secara ketat terhadap respons server aktual dan dipastikan memperoleh status code sesuai spesifikasi ujian.
