const app = require('../app.cjs');
const http = require('http');

/**
 * Script Pengujian Otomatis 12 Skenario Wajib UTS Web Service Engineering
 * SIMADU REST API
 */
async function runTests() {
  const PORT = 3456;
  const server = http.createServer(app);

  await new Promise((resolve) => server.listen(PORT, resolve));
  const baseUrl = `http://localhost:${PORT}`;

  console.log('====================================================================');
  console.log('   MENJALANKAN 12 SKENARIO PENGUJIAN FUNGSIONAL DAN KEAMANAN');
  console.log('                 SIMADU REST API - UTS WSE 2026');
  console.log('====================================================================\n');

  let tokenMhs1 = '';
  let tokenMhs2 = '';
  let tokenAdmin = '';
  let createdPengaduanId = null;

  const testResults = [];

  async function executeTest(no, name, fn) {
    console.log(`--------------------------------------------------------------------`);
    console.log(`[SKENARIO ${no}] ${name}`);
    try {
      const result = await fn();
      const passed = result.actualStatus === result.expectedStatus;
      console.log(`>> Status: ${result.actualStatus} (Expected: ${result.expectedStatus}) -> ${passed ? '✅ PASSED' : '❌ FAILED'}`);
      console.log(`>> Respons: ${JSON.stringify(result.responseBody)}`);
      testResults.push({
        no,
        name,
        passed,
        ...result
      });
    } catch (err) {
      console.error(`>> ERROR pada skenario ${no}:`, err.message);
      testResults.push({
        no,
        name,
        passed: false,
        error: err.message
      });
    }
  }

  // Skenario 1: Login dengan kredensial benar
  await executeTest(1, 'Login dengan kredensial benar', async () => {
    const payload = { id: '240101', password: 'Password123!' };
    const res = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const body = await res.json();
    tokenMhs1 = body.data?.token;

    // Login juga untuk Mhs 2 dan Admin untuk persiapan skenario berikutnya
    const resMhs2 = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: '240102', password: 'Password123!' })
    });
    const bodyMhs2 = await resMhs2.json();
    tokenMhs2 = bodyMhs2.data?.token;

    const resAdmin = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: 'admin01', password: 'AdminPassword123!' })
    });
    const bodyAdmin = await resAdmin.json();
    tokenAdmin = bodyAdmin.data?.token;

    return {
      method: 'POST',
      endpoint: '/api/auth/login',
      requestHeaders: { 'Content-Type': 'application/json' },
      requestBody: payload,
      expectedStatus: 200,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 2: Login dengan password salah
  await executeTest(2, 'Login dengan password salah', async () => {
    const payload = { id: '240101', password: 'SalahPassword123!' };
    const res = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const body = await res.json();
    return {
      method: 'POST',
      endpoint: '/api/auth/login',
      requestHeaders: { 'Content-Type': 'application/json' },
      requestBody: payload,
      expectedStatus: 401,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 3: Akses endpoint terlindungi tanpa token
  await executeTest(3, 'Akses endpoint terlindungi tanpa token', async () => {
    const res = await fetch(`${baseUrl}/api/pengaduan`, {
      method: 'GET'
    });
    const body = await res.json();
    return {
      method: 'GET',
      endpoint: '/api/pengaduan',
      requestHeaders: {},
      requestBody: null,
      expectedStatus: 401,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 4: Akses menggunakan token tidak valid
  await executeTest(4, 'Akses menggunakan token tidak valid', async () => {
    const res = await fetch(`${baseUrl}/api/pengaduan`, {
      method: 'GET',
      headers: {
        'Authorization': 'Bearer token_palsu_tidak_valid_12345xyz'
      }
    });
    const body = await res.json();
    return {
      method: 'GET',
      endpoint: '/api/pengaduan',
      requestHeaders: { 'Authorization': 'Bearer token_palsu_tidak_valid_12345xyz' },
      requestBody: null,
      expectedStatus: 401,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 5: Mahasiswa membuat pengaduan valid
  await executeTest(5, 'Mahasiswa membuat pengaduan valid', async () => {
    const payload = {
      judul: 'Proyektor Ruang 204 Mati Total Saat Perkuliahan',
      kategori: 'Fasilitas',
      deskripsi: 'Saat perkuliahan Sistem Terdistribusi, proyektor tiba-tiba mati dan lampu indikator menyala merah berkedip.'
    };
    const res = await fetch(`${baseUrl}/api/pengaduan`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenMhs1}`
      },
      body: JSON.stringify(payload)
    });
    const body = await res.json();
    createdPengaduanId = body.data?.id;
    return {
      method: 'POST',
      endpoint: '/api/pengaduan',
      requestHeaders: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenMhs1.substring(0, 20)}...`
      },
      requestBody: payload,
      expectedStatus: 201,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 6: Mahasiswa membaca pengaduan sendiri
  await executeTest(6, 'Mahasiswa membaca pengaduan sendiri', async () => {
    const targetId = createdPengaduanId || 1;
    const res = await fetch(`${baseUrl}/api/pengaduan/${targetId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${tokenMhs1}`
      }
    });
    const body = await res.json();
    return {
      method: 'GET',
      endpoint: `/api/pengaduan/${targetId}`,
      requestHeaders: {
        'Authorization': `Bearer ${tokenMhs1.substring(0, 20)}...`
      },
      requestBody: null,
      expectedStatus: 200,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 7: Mahasiswa mencoba membaca pengaduan orang lain
  await executeTest(7, 'Mahasiswa mencoba membaca pengaduan orang lain', async () => {
    // Pengaduan ID 3 adalah milik Mahasiswa 2 (240102). Mahasiswa 1 (240101) mencoba mengaksesnya.
    const res = await fetch(`${baseUrl}/api/pengaduan/3`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${tokenMhs1}`
      }
    });
    const body = await res.json();
    return {
      method: 'GET',
      endpoint: '/api/pengaduan/3',
      requestHeaders: {
        'Authorization': `Bearer ${tokenMhs1.substring(0, 20)}...`
      },
      requestBody: null,
      expectedStatus: 403,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 8: Mahasiswa mengubah status pengaduan
  await executeTest(8, 'Mahasiswa mengubah status pengaduan', async () => {
    // Mahasiswa mencoba memanipulasi status pengaduan (harus ditolak, hanya wewenang Admin)
    const payload = { status: 'diproses' };
    const res = await fetch(`${baseUrl}/api/pengaduan/1/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenMhs1}`
      },
      body: JSON.stringify(payload)
    });
    const body = await res.json();
    return {
      method: 'PATCH',
      endpoint: '/api/pengaduan/1/status',
      requestHeaders: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenMhs1.substring(0, 20)}...`
      },
      requestBody: payload,
      expectedStatus: 403,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 9: Admin melihat seluruh pengaduan
  await executeTest(9, 'Admin melihat seluruh pengaduan', async () => {
    const res = await fetch(`${baseUrl}/api/pengaduan`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${tokenAdmin}`
      }
    });
    const body = await res.json();
    return {
      method: 'GET',
      endpoint: '/api/pengaduan',
      requestHeaders: {
        'Authorization': `Bearer ${tokenAdmin.substring(0, 20)}...`
      },
      requestBody: null,
      expectedStatus: 200,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 10: Admin memperbarui status pengaduan
  await executeTest(10, 'Admin memperbarui status pengaduan', async () => {
    const payload = { status: 'diproses' };
    const res = await fetch(`${baseUrl}/api/pengaduan/1/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenAdmin}`
      },
      body: JSON.stringify(payload)
    });
    const body = await res.json();
    return {
      method: 'PATCH',
      endpoint: '/api/pengaduan/1/status',
      requestHeaders: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenAdmin.substring(0, 20)}...`
      },
      requestBody: payload,
      expectedStatus: 200,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 11: Membuat pengaduan dengan field wajib kosong
  await executeTest(11, 'Membuat pengaduan dengan field wajib kosong', async () => {
    const payload = {
      judul: '',
      kategori: 'Fasilitas',
      deskripsi: 'Deskripsi ada tetapi judul sengaja dikosongkan'
    };
    const res = await fetch(`${baseUrl}/api/pengaduan`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenMhs1}`
      },
      body: JSON.stringify(payload)
    });
    const body = await res.json();
    return {
      method: 'POST',
      endpoint: '/api/pengaduan',
      requestHeaders: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokenMhs1.substring(0, 20)}...`
      },
      requestBody: payload,
      expectedStatus: 400,
      actualStatus: res.status,
      responseBody: body
    };
  });

  // Skenario 12: Mengakses ID pengaduan yang tidak ditemukan
  await executeTest(12, 'Mengakses ID pengaduan yang tidak ditemukan', async () => {
    const res = await fetch(`${baseUrl}/api/pengaduan/99999`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${tokenMhs1}`
      }
    });
    const body = await res.json();
    return {
      method: 'GET',
      endpoint: '/api/pengaduan/99999',
      requestHeaders: {
        'Authorization': `Bearer ${tokenMhs1.substring(0, 20)}...`
      },
      requestBody: null,
      expectedStatus: 404,
      actualStatus: res.status,
      responseBody: body
    };
  });

  console.log('\n====================================================================');
  const allPassed = testResults.every(r => r.passed);
  console.log(`HASIL AKHIR: ${testResults.filter(r => r.passed).length} / ${testResults.length} SKENARIO BERHASIL`);
  console.log(`STATUS: ${allPassed ? '🎉 SEMUA SKENARIO LULUS (100% SUKSES)' : '⚠️ ADA SKENARIO GAGAL'}`);
  console.log('====================================================================\n');

  // Simpan hasil ke file tests/results.json
  const fs = require('fs');
  const path = require('path');
  fs.writeFileSync(
    path.join(__dirname, 'results.json'),
    JSON.stringify(testResults, null, 2),
    'utf-8'
  );

  await new Promise((resolve) => server.close(resolve));
  return allPassed;
}

if (require.main === module) {
  runTests().then(success => {
    process.exit(success ? 0 : 1);
  });
}

module.exports = runTests;
