const { exec } = require('child_process');
const path = require('path');
const app = require('../app.cjs');

const PORT = 3000;
const server = app.listen(PORT, '127.0.0.1', () => {
  console.log(`Server listening on http://127.0.0.1:${PORT}`);
  const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
  const outPath = path.join(__dirname, '..', 'screenshots', 'swagger_ui.png');

  // Berikan waktu sejenak agar Swagger UI route siap
  setTimeout(() => {
    console.log('Mengambil screenshot Swagger UI...');
    const cmd = `"${chromePath}" --headless=new --screenshot="${outPath}" --window-size=1280,1200 "http://127.0.0.1:${PORT}/api-docs/"`;
    exec(cmd, (err, stdout, stderr) => {
      if (err) {
        console.error('Error saat screenshot:', err.message);
      } else {
        console.log('Berhasil mengambil screenshot Swagger UI ke:', outPath);
      }
      server.close(() => {
        console.log('Server ditutup.');
        process.exit(0);
      });
    });
  }, 1500);
});
