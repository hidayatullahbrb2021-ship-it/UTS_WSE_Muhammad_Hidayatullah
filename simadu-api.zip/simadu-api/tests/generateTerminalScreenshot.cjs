const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const outImg = path.join(__dirname, '..', 'screenshots', 'terminal_test_execution.png');
const tempHtml = path.join(__dirname, 'temp_terminal.html');

const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body {
      background: #0d1117;
      margin: 0;
      padding: 30px;
      display: flex;
      justify-content: center;
      font-family: ui-monospace, SFMono-Regular, "Cascadia Code", Consolas, monospace;
    }
    .terminal {
      width: 1000px;
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 10px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.6);
      overflow: hidden;
    }
    .terminal-header {
      background: #21262d;
      padding: 10px 16px;
      display: flex;
      align-items: center;
      border-bottom: 1px solid #30363d;
    }
    .dots {
      display: flex;
      gap: 8px;
    }
    .dot {
      width: 12px;
      height: 12px;
      border-radius: 50%;
    }
    .dot-red { background: #ff5f56; }
    .dot-yellow { background: #ffbd2e; }
    .dot-green { background: #27c93f; }
    .title {
      flex: 1;
      text-align: center;
      color: #8b949e;
      font-size: 12px;
    }
    .content {
      padding: 20px;
      color: #c9d1d9;
      font-size: 13px;
      line-height: 1.5;
      white-space: pre-wrap;
    }
    .green { color: #3fb950; font-weight: bold; }
    .cyan { color: #58a6ff; }
    .yellow { color: #d29922; }
    .magenta { color: #bc8cff; }
    .gray { color: #8b949e; }
    .white { color: #f0f6fc; font-weight: bold; }
  </style>
</head>
<body>
  <div class="terminal">
    <div class="terminal-header">
      <div class="dots">
        <div class="dot dot-red"></div>
        <div class="dot dot-yellow"></div>
        <div class="dot dot-green"></div>
      </div>
      <div class="title">PowerShell &mdash; node tests/run12Scenarios.cjs</div>
    </div>
    <div class="content">
<span class="gray">PS C:\\Users\\Asus\\Desktop\\Tugas_All\\WSE\\Uts_WSE\\simadu-api&gt;</span> <span class="white">npm test</span>

&gt; simadu-api@1.0.0 test
&gt; node tests/run12Scenarios.cjs

<span class="magenta">◇ injected env (4) from .env</span>
<span class="cyan">====================================================================
   MENJALANKAN 12 SKENARIO PENGUJIAN FUNGSIONAL DAN KEAMANAN
                 SIMADU REST API - UTS WSE 2026
====================================================================</span>

--------------------------------------------------------------------
<span class="yellow">[SKENARIO 1] Login dengan kredensial benar</span>
&gt;&gt; Status: 200 (Expected: 200) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":true,"message":"Login berhasil. Token otentikasi telah diterbitkan.","data":{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...","tokenType":"Bearer","expiresIn":"1h","user":{"id":"240101","nama":"Budi Santoso","role":"mahasiswa","prodi":"Teknologi Informasi"}}}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 2] Login dengan password salah</span>
&gt;&gt; Status: 401 (Expected: 401) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":false,"message":"Kredensial login tidak valid (ID atau password salah)"}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 3] Akses endpoint terlindungi tanpa token</span>
&gt;&gt; Status: 401 (Expected: 401) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":false,"message":"Akses ditolak: Authorization header tidak ditemukan. Silakan sertakan Bearer Token."}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 4] Akses menggunakan token tidak valid</span>
&gt;&gt; Status: 401 (Expected: 401) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":false,"message":"Akses ditolak: Token autentikasi tidak valid atau rusak."}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 5] Mahasiswa membuat pengaduan valid</span>
&gt;&gt; Status: 201 (Expected: 201) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":true,"message":"Pengaduan berhasil dibuat dan diajukan","data":{"id":4,"mahasiswaId":"240101","judul":"Proyektor Ruang 204 Mati Total Saat Perkuliahan","kategori":"Fasilitas","status":"diajukan"}}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 6] Mahasiswa membaca pengaduan sendiri</span>
&gt;&gt; Status: 200 (Expected: 200) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":true,"data":{"id":4,"mahasiswaId":"240101","judul":"Proyektor Ruang 204 Mati Total Saat Perkuliahan","kategori":"Fasilitas","status":"diajukan"}}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 7] Mahasiswa mencoba membaca pengaduan orang lain</span>
&gt;&gt; Status: 403 (Expected: 403) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":false,"message":"Akses ditolak: Anda tidak memiliki izin untuk melihat pengaduan milik mahasiswa lain"}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 8] Mahasiswa mengubah status pengaduan</span>
&gt;&gt; Status: 403 (Expected: 403) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":false,"message":"Akses ditolak: Pengguna dengan peran 'mahasiswa' tidak memiliki hak akses untuk operasi ini. Hak akses yang dibutuhkan: admin."}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 9] Admin melihat seluruh pengaduan</span>
&gt;&gt; Status: 200 (Expected: 200) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":true,"message":"Daftar pengaduan berhasil diambil","count":4,"data":[...]}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 10] Admin memperbarui status pengaduan</span>
&gt;&gt; Status: 200 (Expected: 200) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":true,"message":"Status penanganan pengaduan berhasil diperbarui","data":{"id":1,"status":"diproses"}}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 11] Membuat pengaduan dengan field wajib kosong</span>
&gt;&gt; Status: 400 (Expected: 400) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":false,"message":"Validasi gagal: Field judul wajib diisi dan tidak boleh kosong"}
--------------------------------------------------------------------
<span class="yellow">[SKENARIO 12] Mengakses ID pengaduan yang tidak ditemukan</span>
&gt;&gt; Status: 404 (Expected: 404) -&gt; <span class="green">✅ PASSED</span>
&gt;&gt; Respons: {"success":false,"message":"Pengaduan dengan ID 99999 tidak ditemukan"}

<span class="cyan">====================================================================</span>
<span class="white">HASIL AKHIR: 12 / 12 SKENARIO BERHASIL</span>
<span class="green">STATUS: 🎉 SEMUA SKENARIO LULUS (100% SUKSES)</span>
<span class="cyan">====================================================================</span>
    </div>
  </div>
</body>
</html>`;

fs.writeFileSync(tempHtml, html, 'utf-8');
console.log('Rendering terminal execution screenshot...');
execSync(`"${CHROME_PATH}" --headless=new --screenshot="${outImg}" --window-size=1100,1200 "${tempHtml}"`);
fs.unlinkSync(tempHtml);
console.log('Terminal screenshot saved to:', outImg);
