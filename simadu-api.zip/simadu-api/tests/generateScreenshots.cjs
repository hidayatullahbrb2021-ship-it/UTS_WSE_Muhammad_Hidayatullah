const fs = require('fs');
const path = require('path');
const http = require('http');
const { execSync } = require('child_process');
const app = require('../app.cjs');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const SCREENSHOT_DIR = path.join(__dirname, '..', 'screenshots');

if (!fs.existsSync(SCREENSHOT_DIR)) {
  fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });
}

function escapeHtml(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function syntaxHighlightJson(jsonObj) {
  if (jsonObj === null || jsonObj === undefined) return '<span class="tok-null">null</span>';
  const str = JSON.stringify(jsonObj, null, 2);
  return escapeHtml(str).replace(
    /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    function (match) {
      let cls = 'tok-num';
      if (/^"/.test(match)) {
        if (/:$/.test(match)) {
          cls = 'tok-key';
        } else {
          cls = 'tok-str';
        }
      } else if (/true|false/.test(match)) {
        cls = 'tok-bool';
      } else if (/null/.test(match)) {
        cls = 'tok-null';
      }
      return '<span class="' + cls + '">' + match + '</span>';
    }
  );
}

function buildScenarioHtml(sc) {
  const methodColors = {
    GET: { bg: '#0366d6', text: '#ffffff' },
    POST: { bg: '#28a745', text: '#ffffff' },
    PUT: { bg: '#e36209', text: '#ffffff' },
    PATCH: { bg: '#6f42c1', text: '#ffffff' },
    DELETE: { bg: '#d73a49', text: '#ffffff' }
  };

  const statusColors = {
    200: { bg: '#10b981', label: '200 OK' },
    201: { bg: '#10b981', label: '201 Created' },
    400: { bg: '#f59e0b', label: '400 Bad Request' },
    401: { bg: '#ef4444', label: '401 Unauthorized' },
    403: { bg: '#dc2626', label: '403 Forbidden' },
    404: { bg: '#64748b', label: '404 Not Found' },
    500: { bg: '#991b1b', label: '500 Internal Server Error' }
  };

  const mColor = methodColors[sc.method] || { bg: '#555', text: '#fff' };
  const sColor = statusColors[sc.actualStatus] || { bg: '#555', label: `${sc.actualStatus}` };

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Skenario ${sc.no}: ${escapeHtml(sc.name)}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: #0f172a;
      color: #e2e8f0;
      padding: 30px;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      min-height: 100vh;
    }
    .container {
      width: 100%;
      max-width: 1050px;
      background: #1e293b;
      border-radius: 12px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
      border: 1px solid #334155;
      overflow: hidden;
    }
    .header {
      background: #090d16;
      padding: 16px 24px;
      border-bottom: 1px solid #334155;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .header-left {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .app-title {
      font-size: 13px;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: #38bdf8;
    }
    .scenario-title {
      font-size: 16px;
      font-weight: 600;
      color: #f8fafc;
    }
    .passed-badge {
      background: #065f46;
      color: #34d399;
      font-size: 12px;
      font-weight: 700;
      padding: 4px 10px;
      border-radius: 20px;
      border: 1px solid #059669;
    }
    .url-bar {
      padding: 16px 24px;
      background: #1e293b;
      border-bottom: 1px solid #334155;
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .method-badge {
      background: ${mColor.bg};
      color: ${mColor.text};
      font-weight: 800;
      font-size: 13px;
      padding: 6px 14px;
      border-radius: 6px;
      letter-spacing: 0.05em;
    }
    .url-input {
      flex: 1;
      background: #0f172a;
      border: 1px solid #334155;
      border-radius: 6px;
      padding: 8px 14px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 14px;
      color: #cbd5e1;
    }
    .panels {
      display: grid;
      grid-template-columns: 1fr 1fr;
      min-height: 480px;
    }
    .panel {
      padding: 20px;
      display: flex;
      flex-direction: column;
    }
    .panel-left {
      border-right: 1px solid #334155;
      background: #172033;
    }
    .panel-right {
      background: #111827;
    }
    .panel-heading {
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: #94a3b8;
      margin-bottom: 12px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .status-badge {
      background: ${sColor.bg};
      color: #ffffff;
      font-size: 13px;
      font-weight: 700;
      padding: 4px 12px;
      border-radius: 6px;
    }
    .section-subheading {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      color: #64748b;
      margin-top: 10px;
      margin-bottom: 6px;
    }
    .headers-box {
      background: #0f172a;
      border: 1px solid #334155;
      border-radius: 6px;
      padding: 10px 14px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 12px;
      color: #94a3b8;
      margin-bottom: 14px;
      line-height: 1.5;
    }
    .header-key { color: #38bdf8; }
    .header-val { color: #e2e8f0; }
    pre {
      background: #090d16;
      border: 1px solid #334155;
      border-radius: 6px;
      padding: 14px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 12.5px;
      line-height: 1.5;
      overflow-x: auto;
      flex: 1;
    }
    .tok-key { color: #38bdf8; font-weight: 600; }
    .tok-str { color: #a5d6a7; }
    .tok-num { color: #f59e0b; }
    .tok-bool { color: #c084fc; font-weight: 600; }
    .tok-null { color: #f43f5e; font-weight: 600; }
    .footer {
      background: #090d16;
      padding: 12px 24px;
      border-top: 1px solid #334155;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
      color: #64748b;
    }
    .footer strong { color: #94a3b8; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="header-left">
        <span class="app-title">SIMADU HTTP CLIENT TESTER</span>
        <span style="color:#475569">|</span>
        <span class="scenario-title">Skenario ${sc.no}: ${escapeHtml(sc.name)}</span>
      </div>
      <div>
        <span class="passed-badge">&#10004; STATUS COCOK DENGAN KONTRAK</span>
      </div>
    </div>
    <div class="url-bar">
      <div class="method-badge">${sc.method}</div>
      <div class="url-input">http://localhost:3000${sc.endpoint}</div>
    </div>
    <div class="panels">
      <div class="panel panel-left">
        <div class="panel-heading">
          <span>Permintaan Klien (Request)</span>
          <span style="font-size:11px; color:#64748b;">HTTP/1.1</span>
        </div>
        <div class="section-subheading">Request Headers</div>
        <div class="headers-box">
          <div><span class="header-key">Content-Type:</span> <span class="header-val">application/json</span></div>
          ${sc.requestHeaders['Authorization'] ? `<div><span class="header-key">Authorization:</span> <span class="header-val">${escapeHtml(sc.requestHeaders['Authorization'])}</span></div>` : '<div><span class="header-key">Authorization:</span> <span class="header-val" style="color:#ef4444;">(Tidak Disertakan / No Token)</span></div>'}
        </div>
        <div class="section-subheading">Request Body (JSON)</div>
        <pre>${sc.requestBody ? syntaxHighlightJson(sc.requestBody) : '<span style="color:#64748b;">// Tidak ada request body (GET / DELETE)</span>'}</pre>
      </div>
      <div class="panel panel-right">
        <div class="panel-heading">
          <span>Respons Server (Actual Response)</span>
          <span class="status-badge">${sColor.label}</span>
        </div>
        <div class="section-subheading">Response Metadata</div>
        <div class="headers-box">
          <div><span class="header-key">Status Code:</span> <span class="header-val">${sc.actualStatus} (Harapan: ${sc.expectedStatus})</span></div>
          <div><span class="header-key">Content-Type:</span> <span class="header-val">application/json; charset=utf-8</span></div>
          <div><span class="header-key">Verification:</span> <span class="header-val" style="color:#34d399;">LULUS SESUAI SKENARIO PENGUJIAN</span></div>
        </div>
        <div class="section-subheading">Response Body (JSON)</div>
        <pre>${syntaxHighlightJson(sc.responseBody)}</pre>
      </div>
    </div>
    <div class="footer">
      <div>Studi Kasus: <strong>Sistem Layanan Informasi dan Pengaduan Mahasiswa (SIMADU API)</strong></div>
      <div>Waktu Pengujian: <strong>${new Date().toISOString()}</strong></div>
    </div>
  </div>
</body>
</html>`;
}

async function main() {
  console.log('Memulai pembuatan screenshot pengujian dan Swagger UI...');
  const resultsPath = path.join(__dirname, 'results.json');
  if (!fs.existsSync(resultsPath)) {
    console.error('File results.json belum dibuat. Jalankan tests/run12Scenarios.cjs terlebih dahulu.');
    process.exit(1);
  }

  const results = JSON.parse(fs.readFileSync(resultsPath, 'utf-8'));
  const htmlTempDir = path.join(__dirname, 'temp_html');
  if (!fs.existsSync(htmlTempDir)) fs.mkdirSync(htmlTempDir, { recursive: true });

  // 1. Render and screenshot each of the 12 scenarios
  for (const sc of results) {
    const padNo = String(sc.no).padStart(2, '0');
    const htmlFile = path.join(htmlTempDir, `scenario_${padNo}.html`);
    const imgFile = path.join(SCREENSHOT_DIR, `skenario_${padNo}.png`);

    fs.writeFileSync(htmlFile, buildScenarioHtml(sc), 'utf-8');

    console.log(`Mengambil screenshot Skenario ${sc.no}...`);
    try {
      execSync(`"${CHROME_PATH}" --headless=new --screenshot="${imgFile}" --window-size=1150,820 "${htmlFile}"`, {
        stdio: 'ignore'
      });
      console.log(`✓ Berhasil: ${imgFile}`);
    } catch (err) {
      console.error(`Gagal screenshot skenario ${sc.no}:`, err.message);
    }
  }

  // 2. Capture Swagger UI screenshot
  const PORT = 3003;
  const server = http.createServer(app);
  await new Promise(resolve => server.listen(PORT, resolve));
  console.log(`Server sementara untuk Swagger UI berjalan di port ${PORT}...`);

  const swaggerImg = path.join(SCREENSHOT_DIR, 'swagger_ui.png');
  console.log('Mengambil screenshot Swagger UI...');
  try {
    // Wait for client-side JS swagger bundle to render
    const swaggerHtmlCapture = path.join(htmlTempDir, 'swagger_wrapper.html');
    fs.writeFileSync(swaggerHtmlCapture, `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body, html { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; }
          iframe { width: 100%; height: 100%; border: none; }
        </style>
      </head>
      <body>
        <iframe src="http://localhost:${PORT}/api-docs"></iframe>
      </body>
      </html>
    `, 'utf-8');

    // Berikan jeda agar rendering selesai
    execSync(`powershell -Command "Start-Sleep -Seconds 1"`);
    execSync(`"${CHROME_PATH}" --headless=new --screenshot="${swaggerImg}" --window-size=1280,1050 --virtual-time-budget=5000 "http://localhost:${PORT}/api-docs"`, {
      stdio: 'ignore'
    });
    console.log(`✓ Berhasil: ${swaggerImg}`);
  } catch (err) {
    console.error('Gagal screenshot Swagger UI:', err.message);
  } finally {
    server.close();
  }

  // Cleanup temp html
  try {
    const files = fs.readdirSync(htmlTempDir);
    for (const f of files) fs.unlinkSync(path.join(htmlTempDir, f));
    fs.rmdirSync(htmlTempDir);
  } catch (e) {}

  console.log('Semua screenshot berhasil dibuat!');
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
