const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const swaggerUi = require('swagger-ui-express');
const dotenv = require('dotenv');

// Muat environment variables
dotenv.config();

const apiRoutes = require('./src/routes/index.cjs');
const errorHandler = require('./src/middleware/errorHandler.cjs');

const app = express();

// Middleware Global
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Swagger UI Documentation
const openApiPath = path.join(__dirname, 'docs', 'openapi.json');
if (fs.existsSync(openApiPath)) {
  const openApiDoc = JSON.parse(fs.readFileSync(openApiPath, 'utf-8'));
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(openApiDoc, {
    customSiteTitle: 'SIMADU REST API - Dokumentasi Swagger UI'
  }));
}

// Redirect root to /api-docs
app.get('/', (req, res) => {
  res.redirect('/api-docs');
});

// Routing API
app.use('/api', apiRoutes);

// 404 Handler untuk route yang tidak terdaftar
app.use((req, res, next) => {
  res.status(404).json({
    success: false,
    message: `Endpoint '${req.method} ${req.originalUrl}' tidak ditemukan pada server SIMADU API.`
  });
});

// Centralized Error Handling Middleware
app.use(errorHandler);

module.exports = app;
